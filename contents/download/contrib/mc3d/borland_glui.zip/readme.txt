This file contains instructions for compiling the GLUI library
and example programs for Windows using the free command-line C++
compiler from Borland (INPRISE).  -Ross Piltz


INSTALLING THE BORLAND COMPILER

First, download the free compiler from www.borland.com.
I assume in the following that you install it to the
default directory of C:\BORLAND\BCC55.

With an editor make the following "bcc32.cfg" file:
-D_BORLAND
-IC:\BORLAND\BCC55\INCLUDE
-LC:\BORLAND\BCC55\LIB

and "ilink32.cfg" file:
-LC:\BORLAND\BCC55\INCLUDE

and put the files in the C:\BORLAND\BCC55\BIN directory.  Don't
take Borland's advice of putting the *.CFG in your working directory
unless you want to have different configurations in every directory.

Edit C:\AUTOEXEC.BAT inserting the line:
PATH=%PATH%;C:\BORLAND\BCC55\BIN

Next restart your PC and try typing the MSDOS command
BCC32 | MORE
You should get a page of stuff about compiler options, and the
version number of the compiler at the top of the page.
(The version I have is Borland C++ v5.5.1)

You may have read that you have to make "glu32.lib" & "opengl32.lib"
files using the IMPLIB command.  That is old stuff, forget it.
Borland now has both libraries in their "import32.lib" file.


INSTALLING GLUT

Get a copy of GLUT for windows from the "GLUT for Win32" homepage
at http://www.xmission.com/~nate/glut.html.  We only need the
DLL zip file to run GLUI, but if you have the time there are
several interesting examples and demos in the source zip file.
(The version of GLUT I downloaded was 3.7.2)

Extract the files from the zip and run the following MSDOS commands
on them:

COPY GLUT.H C:\BORLAND\BCC55\INCLUDE\GL
COPY GLUT32.DLL C:\WINDOWS\SYSTEM
CD \BORLAND\BCC55\LIB
IMPLIB GLUT32.LIB C:\WINDOWS\SYSTEM\GLUT32.DLL


INSTALLING GLUI

First download GLUI from:
http://www.cs.unc.edu/~rademach/glui/#beta_v2
I used "Version 2.0 Beta".  This has been a beta version for
several months, don't hold your breath on a recent update.

Copy the directory containing this file to a subdirectory of GLUI.
Make sure the directory is called BORLAND.  Using MSDOS, go to
the BORLAND sub-directory and use the command:
MAKELIBS.BAT

Hopefully all will go well and you now have a GLUI.LIB file which
has been copied to C:\BORLAND\BCC55\LIB, as well as the GLUI.H file
being copied to C:\BORLAND\BCC55\INCLUDE\GL.
 
Next, go to the C:\BORLAND\BCC55\INCLUDE\GL directory and edit
the GLUT.H file, inserting the line:
#include <GL/glui.h>
at the beginning of the file.  This will affect any GLUT-only programs,
see later section on how to compile such programs.

Compile the five examples files (from the BORLAND directory) using:
BCC32 -w- examples1.cpp
...
BCC32 -w- examples5.cpp


COMPILING YOUR OWN GLUI PROGRAMS

1) Put the line
borland_GL_setup();
   in your program prior to calling any GL** routines.

2) Include <GL/glui.h> in any files that use GLUI or GLUT.
   You don't have to include glut.h because glui.h does already.

3) Compile your program using the MSDOS command (leave out -w- if
   you don't mind the warning messages):
BCC32 -w- your_prog.cpp


HOW TO COMPILE GLUT (BUT NOT GLUI) PROGRAMS

The quick answer is:

1) Change any *.C files which include <GL/glut.h> to *.CPP files.

2) Change all <GL/glut.h> includes to <GL/glui.h>.

3) Put the line
borland_GL_setup();
   in your program prior to calling any GL** routines.

4) Compile your program using the MSDOS command (leave out -w- if
   you don't mind the warning messages):
BCC32 -w- your_prog.cpp

The above seems to be effective at compiling most of the GLUT-only
programs in the GLUT *.tar.gz distribution.


HINTS ON COMPILING PROGRAMS

Make sure you compile the example files in the BORLAND sub-directory
not the main GLUI directory.

I have put the GLUI library and include files in system directories.
Therefore, programs should include <GL/glui.h> not "glui.h".

You have to change the names of all C files that include glui.h or
glut.h to *.cpp so that glui.h can be processed correctly.

If the compiler complains about "overloaded functions" then you
probably didn't edit "glut.h" as I suggested and you have included
"glut.h" instead of "glui.h".

If the program doesn't run properly or it crashes with an "exception
10h" error, then you probably forgot the "borland_GL_setup()" routine.
You may have to restart your PC after one of these crashes to get the
"borland_GL_setup()" fix to work properly.

If you get a linker error that opengl32.lib or glu32.lib could not be
found, then the software probably has a pragma line trying to autoload
these libraries.  As stated earlier, Borland have combined these two
libraries (and others) into import32.lib.  You will have to disable
the pragma line that autoloads the old libraries.


========PLEASE HELP ME FIX THESE PROBLEMS===========

Explicitly calling borland_GL_setup() is a pain, can someone suggest
a suitable place in GLUI (or GLUT) to run this command automatically.

The glui.h contains preprocessor definitions that affect the
compilation of glut.h to ensure it doesn't crash the compiler. This
is a complete and utter kludge!  I don't know what it's side effects
are, all I know is it works and everything seems OK.  My C++ skills
are pathetic, could some REAL C++ programmer look at it, please.
