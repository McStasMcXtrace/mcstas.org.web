'''
Created on 21 Jan 2015

@author: Deon Marais (deon.marais@necsa.co.za)
@organization: The South African Nuclear Energy Corporation (Necsa) SOC Limited
@copyright: See copyright.txt
'''
from PyQt4 import QtGui as qt
from McPSDEF import McPSDEF
import sys

if __name__ == '__main__':
    app = qt.QApplication(sys.argv)
    window = McPSDEF()
    window.show()
    sys.exit(app.exec_())
    pass