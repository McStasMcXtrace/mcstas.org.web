This is a short guide on how to simulate a Spin-Echo Modulated Small Angle Neutron Scattering instrument (SEMSANS) using McStas and

components:
Analyser_ideal.comp
Pol_pi_2_rotator.comp
Pol_triafield.comp

and instrument file:
SEMSANS_instrument.instr

The Analyser_ideal component is written by Erik Knudsen and works as an (Unphysical) ideal analyser of neutron spin direction.
The Pol_pi_2_rotator component is also written by Erik Knudsen and rotates the neutron spin 90 degrees around a given vector. It is an ideal unphysical version of a V-coil.
The Pol_triafield is witten by Morten Sales and is an ideal unphysical triangular field. The amount of precession a neutron spin would experience passing through the field is calculated and applied. More information can be found in the code for the component.

The SEMSANS_instrument is the instrument file for the SEMSANS instrument.
It works by having a 
source, 
double-chopper, 
polariser, 
slit, 
2 V-coils, 
1st precessionfield (called guidefield), 
triangular field (with precessionfield included), 
2nd precessionfield, 
2 V-coils, 
3rd precessionfield, 
triangular field, 
4th precessionfield (with precessionfield included), 
2 V-coils, 
slit, 
analyser, 
choice of single slit, double slit or grating,
Time of Flight (TOF) detector.
(More information can be found in the code of the instrument file)

The position of the 2 V-coils in the middle responsible for the 180 degree spin flip can be scanned with the parameter flippos.
The start orientation of the neutron spin is controlled with the parameter FLIP where 1 is ‘down’ and -1 is up’. This parameter works in the first V-coil.

After the simulation where flippos has been scanned for both FLIP 1 and -1, the output from the TOF detector can be combined into as e.g. a 2D colorplot of Polarisation signal vs TOF (wavelength) and flippos.

Regards,
Morten Sales (morten.sales@helmholtz-berlin.de and morten.sales@gmail.com)
