MC2D & MC3D - replacements for the McStas display GUI's

(If you can think of better names, tell me! -Ross Piltz)

I designed these programs to run on windows & unix platforms
based on the OpenGL graphics engine.  The GUI is provided by
the GLUI library which is built on top of the GLUT library.
OpenGL and GLUT are industry standards and are probably already
installed on your machine. GLUI appears to be a hobby project,
but it works well and I like the look of its interface.

GLUT is available at:
http://reality.sgi.com/mjk_asd/glut3/glut3.html
I used version 3.7.

GLUI is available at:
http://www.cs.unc.edu/~rademach/glui/#beta_v2
I used version 2.0 beta.

For unix:
  Download the source files from the above sites.
  Follow the instructions in the installation files.
  The include files glut.h & glui.h should be copied to a GL
  sub-directory of the system's include directory, or just to
  any GL sub-directory in your files.
  Similarly, the library files libglut.h & libglui.h should be
  copied to the system's library directory, or just to any
  directory in your files.
  Edit the makefile for mc2d & mc3d for your system.  In
  particular, change the directories where the include and
  library files are located.  The software expects the include
  files in <GL/...> so point the include directory not to where
  the includes files are but one directory up, and make sure the
  files are in a directory called GL.
  
For windows:
  Copy the precompiled GLUT libraries from:
    http://www.xmission.com/~nate/glut.html
  Download the GLUI source files.
  GLUI was originally compiled using MSVC but I used the free
  command line compiler from Borland.  (I haven't tried gcc).
  The instructions for compiling GLUI using the Borland compiler
  are given in the borland_glui.zip file included where you found
  this file.
  You can use MSVC if you wish, but the mc2d & mc3d programs have
  only been tested with the Borland compiler (and the SGI unix
  compiler), so you may have to fix some compiler dependent bugs.  
  Even if you use MSVC make sure you read the readme.txt file in
  borland_glui.zip for any useful information.

For Mac:
  Sorry, you are on your own!
  I expect that GLUT exists for a mac, but GLUI certainly doesn't.
  That being said, GLUI derives all of it's functions from GLUT so
  it should be possible to get it going - FLW (famous last words).

Changes to McStas:
  I have made no software changes to McStas, instead I have
  changed the component library by adding more command to the
  MCDISPLAY section. These changes cause lines starting with
  "MC3D:" to be written to the standard output if the simulation
  is run with the -t option.  The editted components files are
  contained in the mc3d_components.zip file.  This file also
  includes an editted "prisma2.instr" file which I have use as
  an example.  To run mc3d you have to copy these new components
  over the old ones (backup the old ones first!).

Running MC3D & MC2D:
  I will use the prisma2 example contained in mc3d_components.zip.
  First we make up the prisma2 executable with the trace option.
  (bcc32 is the Borland compiler command on windows)
    mcstas --trace prisma2.instr
    bcc32 -w- prisma2.c
  Run the executable with the -t option to dump trace information to
  a file (trace.out) which is read by mc3d.  We also add a limited
  number of neutron traces to stop the files getting too big.
    prisma2 -t -n1e3 TT=-30 PHA=22 PHA1=-3 PHA2=-2 PHA3=-1 PHA4=0 PHA5=1 PHA6=2 PHA7=3 TTA=44 > trace.out
  Now run the executable to get good statistics for display by mc2d.
    prisma2 -n1e6 TT=-30 PHA=22 PHA1=-3 PHA2=-2 PHA3=-1 PHA4=0 PHA5=1 PHA6=2 PHA7=3 TTA=44
  Tell mc3d to read component and trace information from trace.out.
    mc3d trace.out
  Display 2D monitor outputs according to information in mcstas.sim.
    mc2d

TO DO LIST:
  I think it would be best if components had a special MC3D section
  instead of me using the MCDISPLAY section.  As well, the MC3D
  lines and other component definition lines are only output when
  the -t option is turned on.  It would be best if the necessary
  output was always turned on and if the output was written to a
  separate file.
  Implement some output for 1D (& 0D) monitors from MC2D.
  Add option to "texture" 2D (& possibly 1D) monitors with an
  intensity distribution in MC3D.
  Change MC2D to read "all in one file" data from mcstas.sim.
  Make programs work with directory names so it is easy to switch
  between different simulations.
  Explain what the various "MC3D:" lines actually mean.  You can find
  out yourself by looking in draw.cpp.
