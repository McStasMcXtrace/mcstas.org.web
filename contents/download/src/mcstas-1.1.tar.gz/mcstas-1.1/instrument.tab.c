
/*  A Bison parser, made from instrument.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	TOK_RESTRICTED	258
#define	TOK_GENERAL	259
#define	TOK_ABSOLUTE	260
#define	TOK_AT	261
#define	TOK_COMPONENT	262
#define	TOK_DECLARE	263
#define	TOK_DEFINE	264
#define	TOK_DEFINITION	265
#define	TOK_END	266
#define	TOK_FINALLY	267
#define	TOK_EXTERN	268
#define	TOK_INITIALIZE	269
#define	TOK_INSTRUMENT	270
#define	TOK_MCDISPLAY	271
#define	TOK_OUTPUT	272
#define	TOK_PARAMETERS	273
#define	TOK_POLARISATION	274
#define	TOK_RELATIVE	275
#define	TOK_ROTATED	276
#define	TOK_SETTING	277
#define	TOK_STATE	278
#define	TOK_TRACE	279
#define	TOK_ID	280
#define	TOK_STRING	281
#define	TOK_NUMBER	282
#define	TOK_CODE_START	283
#define	TOK_CODE_END	284
#define	TOK_CODE_LINE	285
#define	TOK_INVALID	286

#line 13 "instrument.y"

#include <math.h>
#include <string.h>
#include <stdio.h>

#include "mcstas.h"

#define YYERROR_VERBOSE 1
#define YYDEBUG 1

/* When a bison parser needs to extend the parser stack, by default it uses
* the alloca() function. This causes portability problems (eg. for Win32 and
* HPUX). To avoid that, we use our own method for extending the stack. This
* is a bit tricky and reliant on bison internals, but important for portability. 
*/

#define yyoverflow mc_yyoverflow
int mc_yyoverflow();

#line 41 "instrument.y"
typedef union {
  double number;
  char *string;
  struct code_block *ccode;	/* User-supplied C code block. */
  CExp exp;			/* Expression datatype (for arguments). */
  int linenum;			/* Starting line number for code block. */
  Coords_exp coords;		/* Coordinates for location or rotation. */
  List formals;			/* List of formal parameters. */
  Symtab actuals;		/* Values for formal parameters. */
  char **polform;		/* Polarisation state formal parameters */
  struct {List def, set, out, state;
	  char **polarisation;} parms;	/* Parameter lists. */
  struct instr_def *instrument;	/* Instrument definition. */
  struct comp_inst *instance;	/* Component instance. */
  struct comp_place place;	/* Component place. */
  struct comp_orientation ori;	/* Component orientation. */
} YYSTYPE;
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		119
#define	YYFLAG		-32768
#define	YYNTBASE	36

#define YYTRANSLATE(x) ((unsigned)(x) <= 286 ? yytranslate[x] : 69)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    32,
    34,     2,     2,    33,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    35,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     4,     7,     8,    11,    22,    28,    32,    36,    37,
    41,    45,    46,    56,    57,    68,    69,    72,    73,    76,
    79,    80,    83,    84,    87,    90,    91,    94,   102,   106,
   107,   109,   111,   115,   119,   120,   122,   126,   132,   136,
   137,   141,   143,   146,   148,   156,   158,   160,   163,   165,
   169,   170
};

static const short yyrhs[] = {     4,
    37,    45,     0,     3,    38,     0,     0,    37,    38,     0,
     9,     7,    25,    39,    47,    48,    49,    50,    51,    11,
     0,    40,    41,    42,    43,    44,     0,    10,    18,    55,
     0,    22,    18,    55,     0,     0,    17,    18,    55,     0,
    23,    18,    55,     0,     0,    19,    18,    32,    25,    33,
    25,    33,    25,    34,     0,     0,     9,    15,    25,    55,
    46,    47,    48,    52,    50,    11,     0,     0,     8,    67,
     0,     0,    14,    67,     0,    24,    67,     0,     0,    12,
    67,     0,     0,    16,    67,     0,    24,    53,     0,     0,
    53,    54,     0,     7,    25,    35,    25,    58,    61,    62,
     0,    32,    56,    34,     0,     0,    57,     0,    25,     0,
    57,    33,    25,     0,    32,    59,    34,     0,     0,    60,
     0,    25,    35,    66,     0,    60,    33,    25,    35,    66,
     0,     6,    65,    63,     0,     0,    21,    65,    63,     0,
     5,     0,    20,    64,     0,    25,     0,    32,    66,    33,
    66,    33,    66,    34,     0,    25,     0,    27,     0,    13,
    25,     0,    26,     0,    28,    68,    29,     0,     0,    68,
    30,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   106,   107,   110,   111,   114,   137,   148,   154,   160,   164,
   170,   176,   180,   191,   193,   208,   212,   218,   222,   228,
   234,   238,   244,   248,   254,   256,   261,   300,   327,   334,
   338,   344,   349,   356,   362,   366,   372,   378,   386,   393,
   398,   407,   411,   418,   435,   443,   465,   469,   475,   482,
   491,   496
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","TOK_RESTRICTED",
"TOK_GENERAL","\"ABSOLUTE\"","\"AT\"","\"COMPONENT\"","\"DECLARE\"","\"DEFINE\"",
"\"DEFINITION\"","\"END\"","\"FINALLY\"","\"EXTERN\"","\"INITIALIZE\"","\"INSTRUMENT\"",
"\"MCDISPLAY\"","\"OUTPUT\"","\"PARAMETERS\"","\"POLARISATION\"","\"RELATIVE\"",
"\"ROTATED\"","\"SETTING\"","\"STATE\"","\"TRACE\"","TOK_ID","TOK_STRING","TOK_NUMBER",
"TOK_CODE_START","TOK_CODE_END","TOK_CODE_LINE","TOK_INVALID","'('","','","')'",
"'='","main","compdefs","compdef","parameters","def_par","set_par","out_par",
"state_par","polarisation_par","instrument","@1","declare","initialize","trace",
"finally","mcdisplay","instr_trace","complist","component","formallist","formals",
"formals1","actuallist","actuals","actuals1","place","orientation","reference",
"compref","coords","exp","codeblock","code", NULL
};
#endif

static const short yyr1[] = {     0,
    36,    36,    37,    37,    38,    39,    40,    41,    42,    42,
    43,    44,    44,    46,    45,    47,    47,    48,    48,    49,
    50,    50,    51,    51,    52,    53,    53,    54,    55,    56,
    56,    57,    57,    58,    59,    59,    60,    60,    61,    62,
    62,    63,    63,    64,    65,    66,    66,    66,    66,    67,
    68,    68
};

static const short yyr2[] = {     0,
     3,     2,     0,     2,    10,     5,     3,     3,     0,     3,
     3,     0,     9,     0,    10,     0,     2,     0,     2,     2,
     0,     2,     0,     2,     2,     0,     2,     7,     3,     0,
     1,     1,     3,     3,     0,     1,     3,     5,     3,     0,
     3,     1,     2,     1,     7,     1,     1,     2,     1,     3,
     0,     2
};

static const short yydefact[] = {     0,
     0,     3,     0,     2,     0,     0,     0,     4,     1,     0,
     0,     0,    16,     0,     0,     0,     0,    18,     0,     9,
    30,    14,     7,    51,    17,     0,     0,     0,     0,     0,
    32,     0,    31,    16,     0,    19,     0,    21,     8,     0,
     0,    12,    29,     0,    18,    50,    52,    20,     0,    23,
    10,     0,     0,     6,    33,     0,    22,     0,     0,    11,
     0,    26,    21,    24,     5,     0,    25,     0,     0,     0,
    27,    15,     0,     0,     0,     0,     0,     0,     0,    35,
     0,    13,     0,     0,    36,     0,    40,     0,    34,     0,
     0,     0,     0,    28,     0,    46,    49,    47,    37,     0,
     0,    42,     0,    39,     0,    48,     0,     0,    44,    43,
    41,    38,     0,     0,     0,    45,     0,     0,     0
};

static const short yydefgoto[] = {   117,
     5,     4,    13,    14,    20,    30,    42,    54,     9,    34,
    18,    27,    38,    50,    59,    63,    67,    71,    22,    32,
    33,    81,    84,    85,    87,    94,   104,   110,    92,    99,
    25,    35
};

static const short yypact[] = {     1,
     0,-32768,     3,-32768,     8,   -14,    -1,-32768,-32768,    11,
    -7,     4,    15,     9,    -2,    -2,     5,    18,    17,    20,
    13,-32768,-32768,-32768,-32768,     5,    16,    -2,    21,    19,
-32768,     7,    10,    15,   -22,-32768,     5,    32,-32768,    -2,
    27,    28,-32768,    23,    18,-32768,-32768,-32768,     5,    30,
-32768,    -2,    31,-32768,-32768,    26,-32768,     5,    40,-32768,
    22,-32768,    32,-32768,-32768,    33,    45,    42,    24,    34,
-32768,-32768,    35,    29,    36,    37,    38,    39,    41,    43,
    49,-32768,    44,    46,    48,    50,    51,     2,-32768,    52,
     2,    -4,    50,-32768,    53,-32768,-32768,-32768,-32768,    54,
    55,-32768,    58,-32768,    -4,-32768,     2,     2,-32768,-32768,
-32768,-32768,    57,     2,    59,-32768,    56,    61,-32768
};

static const short yypgoto[] = {-32768,
-32768,    60,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    62,    25,-32768,    47,-32768,-32768,-32768,-32768,   -16,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,   -39,-32768,   -26,   -88,
   -24,-32768
};


#define	YYLAST		110


static const short yytable[] = {    23,
   102,    36,   101,     1,     2,     6,    46,    47,     3,     6,
    10,    39,    48,    11,    95,   103,     7,    15,   112,   113,
    12,    16,    17,    51,    57,   115,    96,    97,    98,    21,
    19,    26,    24,    64,    28,    60,    29,    31,    40,    37,
    43,    41,    44,    49,    52,    58,    53,    55,    61,    62,
    65,    70,    72,    66,    86,   118,    73,    69,    74,    75,
   119,    78,    79,    76,     8,   111,   105,    83,    77,    56,
    80,    93,     0,     0,    82,     0,   100,   106,    88,    89,
    90,    91,   109,     0,     0,     0,     0,   108,   107,   114,
     0,     0,   116,     0,     0,    45,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    68
};

static const short yycheck[] = {    16,
     5,    26,    91,     3,     4,     7,    29,    30,     9,     7,
    25,    28,    37,    15,    13,    20,     9,    25,   107,   108,
    10,    18,     8,    40,    49,   114,    25,    26,    27,    32,
    22,    14,    28,    58,    18,    52,    17,    25,    18,    24,
    34,    23,    33,    12,    18,    16,    19,    25,    18,    24,
    11,     7,    11,    32,     6,     0,    33,    25,    25,    25,
     0,    25,    25,    35,     5,   105,    93,    25,    33,    45,
    32,    21,    -1,    -1,    34,    -1,    25,    25,    35,    34,
    33,    32,    25,    -1,    -1,    -1,    -1,    33,    35,    33,
    -1,    -1,    34,    -1,    -1,    34,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    63
};
#define YYPURE 1

/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/share/misc/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 196 "/usr/share/misc/bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 5:
#line 115 "instrument.y"
{
		    struct comp_def *c;
		    palloc(c);
		    c->name = yyvsp[-7].string;
		    c->def_par = yyvsp[-6].parms.def;
		    c->set_par = yyvsp[-6].parms.set;
		    c->out_par = yyvsp[-6].parms.out;
		    c->state_par = yyvsp[-6].parms.state;
		    c->polarisation_par = yyvsp[-6].parms.polarisation;
		    c->decl_code = yyvsp[-5].ccode;
		    c->init_code = yyvsp[-4].ccode;
		    c->trace_code = yyvsp[-3].ccode;
		    c->finally_code = yyvsp[-2].ccode;
		    c->mcdisplay_code = yyvsp[-1].ccode;

		    /* Check definition and setting params for uniqueness */
		    check_comp_formals(c->def_par, c->set_par, c->name);
		    /* Put component definition in table. */
		    symtab_add(read_components, c->name, c);
		  ;
    break;}
case 6:
#line 138 "instrument.y"
{
		    yyval.parms.def = yyvsp[-4].formals;
		    yyval.parms.set = yyvsp[-3].formals;
		    yyval.parms.out = yyvsp[-2].formals;
		    yyval.parms.state = yyvsp[-1].formals;
		    yyval.parms.polarisation = yyvsp[0].polform;
		  ;
    break;}
case 7:
#line 149 "instrument.y"
{
		    yyval.formals = yyvsp[0].formals;
		  ;
    break;}
case 8:
#line 155 "instrument.y"
{
		    yyval.formals = yyvsp[0].formals;
		  ;
    break;}
case 9:
#line 161 "instrument.y"
{
		    yyval.formals = list_create();
		  ;
    break;}
case 10:
#line 165 "instrument.y"
{
		    yyval.formals = yyvsp[0].formals;
		  ;
    break;}
case 11:
#line 171 "instrument.y"
{
		    yyval.formals = yyvsp[0].formals;
		  ;
    break;}
case 12:
#line 177 "instrument.y"
{
		    yyval.polform = NULL;
		  ;
    break;}
case 13:
#line 181 "instrument.y"
{
		    char **polform;
		    nalloc(polform, 3);
		    polform[0] = yyvsp[-5].string;
		    polform[1] = yyvsp[-3].string;
		    polform[2] = yyvsp[-1].string;
		    yyval.polform = polform;
		  ;
    break;}
case 14:
#line 192 "instrument.y"
{ instrument_definition->formals = yyvsp[0].formals; ;
    break;}
case 15:
#line 194 "instrument.y"
{
		    instrument_definition->name = yyvsp[-7].string;
		    instrument_definition->decls = yyvsp[-4].ccode;
		    instrument_definition->inits = yyvsp[-3].ccode;
		    instrument_definition->finals = yyvsp[-1].ccode;
		    instrument_definition->compmap = comp_instances;
		    instrument_definition->complist = comp_instances_list;

		    /* Check instrument parameterss for uniqueness */
		    check_instrument_formals(instrument_definition->formals,
					     instrument_definition->name);
		  ;
    break;}
case 16:
#line 209 "instrument.y"
{
		    yyval.ccode = codeblock_new();
		  ;
    break;}
case 17:
#line 213 "instrument.y"
{
		    yyval.ccode = yyvsp[0].ccode;
		  ;
    break;}
case 18:
#line 219 "instrument.y"
{
		    yyval.ccode = codeblock_new();
		  ;
    break;}
case 19:
#line 223 "instrument.y"
{
		    yyval.ccode = yyvsp[0].ccode;
		  ;
    break;}
case 20:
#line 229 "instrument.y"
{
		    yyval.ccode = yyvsp[0].ccode;
		  ;
    break;}
case 21:
#line 235 "instrument.y"
{
		    yyval.ccode = codeblock_new();
		  ;
    break;}
case 22:
#line 239 "instrument.y"
{
		    yyval.ccode = yyvsp[0].ccode;
		  ;
    break;}
case 23:
#line 245 "instrument.y"
{
		    yyval.ccode = codeblock_new();
		  ;
    break;}
case 24:
#line 249 "instrument.y"
{
		    yyval.ccode = yyvsp[0].ccode;
		  ;
    break;}
case 26:
#line 257 "instrument.y"
{
		    comp_instances = symtab_create();
		    comp_instances_list = list_create();
		  ;
    break;}
case 27:
#line 262 "instrument.y"
{
		    /* Check that the component instance name has not
                       been used before. */
		    if(symtab_lookup(comp_instances, yyvsp[0].instance->name))
		    {
		      print_error("Multiple use of component instance name "
				  "'%s'.\n", yyvsp[0].instance->name);
		      /* Since this is an error condition, we do not
		         worry about freeing the memory allocated for
			 the component instance. */
		    }
		    else
		    {
		      symtab_add(comp_instances, yyvsp[0].instance->name, yyvsp[0].instance);
		      list_add(comp_instances_list, yyvsp[0].instance);
		      if(yyvsp[0].instance->def)
		      {
			/* Check if the component handles polarisation. */
			if(yyvsp[0].instance->def->polarisation_par)
			{
			  instrument_definition->polarised = 1;
			}
			else
			{
			  if(instrument_definition->polarised)
			  {
			    print_warn(NULL,
				       "Component %s does not handle "
				       "neutron polarisation,\n"
				       "but the components before it do.\n",
				       yyvsp[0].instance->name);
			  }
			}
		      }
		    }
		  ;
    break;}
case 28:
#line 301 "instrument.y"
{
		    struct comp_def *def;
		    struct comp_inst *comp;

		    def = read_component(yyvsp[-3].string);
		    palloc(comp); /* Allocate new instance. */
		    comp->name = yyvsp[-5].string;
		    comp->def = def;
		    palloc(comp->pos);
		    comp->pos->place = yyvsp[-1].place.place;
		    comp->pos->place_rel = yyvsp[-1].place.place_rel;
		    comp->pos->orientation = yyvsp[0].ori.orientation;
		    comp->pos->orientation_rel =
		      yyvsp[0].ori.isdefault ? yyvsp[-1].place.place_rel : yyvsp[0].ori.orientation_rel;
		    if(def != NULL)
		    {
		      /* Check actual parameters against definition and
                         setting parameters. */
		      comp_formals_actuals(comp, yyvsp[-2].actuals);
		    }
		    str_free(yyvsp[-3].string);
		    debugn((DEBUG_HIGH, "Component: %s.\n", yyvsp[-5].string));
		    yyval.instance = comp;
		  ;
    break;}
case 29:
#line 328 "instrument.y"
{
		    yyval.formals = yyvsp[-1].formals;
		  ;
    break;}
case 30:
#line 335 "instrument.y"
{
		    yyval.formals = list_create();
		  ;
    break;}
case 31:
#line 339 "instrument.y"
{
		    yyval.formals = yyvsp[0].formals;
		  ;
    break;}
case 32:
#line 345 "instrument.y"
{
		    yyval.formals = list_create();
		    list_add(yyval.formals, yyvsp[0].string);
		  ;
    break;}
case 33:
#line 350 "instrument.y"
{
		    list_add(yyvsp[-2].formals, yyvsp[0].string);
		    yyval.formals = yyvsp[-2].formals;
		  ;
    break;}
case 34:
#line 357 "instrument.y"
{
		    yyval.actuals = yyvsp[-1].actuals;
		  ;
    break;}
case 35:
#line 363 "instrument.y"
{
		    yyval.actuals = symtab_create();
		  ;
    break;}
case 36:
#line 367 "instrument.y"
{
		    yyval.actuals = yyvsp[0].actuals;
		  ;
    break;}
case 37:
#line 373 "instrument.y"
{
		    yyval.actuals = symtab_create();
		    symtab_add(yyval.actuals, yyvsp[-2].string, yyvsp[0].exp);
		    str_free(yyvsp[-2].string);
		  ;
    break;}
case 38:
#line 379 "instrument.y"
{
		    symtab_add(yyvsp[-4].actuals, yyvsp[-2].string, yyvsp[0].exp);
		    str_free(yyvsp[-2].string);
		    yyval.actuals = yyvsp[-4].actuals;
		  ;
    break;}
case 39:
#line 387 "instrument.y"
{
		    yyval.place.place = yyvsp[-1].coords;
		    yyval.place.place_rel = yyvsp[0].instance;
		  ;
    break;}
case 40:
#line 394 "instrument.y"
{
		    yyval.ori.orientation = coords_exp_origo(); /* Default to (0,0,0). */
		    yyval.ori.isdefault = 1; /* No ROTATED modifier was present */
		  ;
    break;}
case 41:
#line 399 "instrument.y"
{
		    yyval.ori.orientation = yyvsp[-1].coords;
		    yyval.ori.orientation_rel = yyvsp[0].instance;
		    yyval.ori.isdefault = 0;
		  ;
    break;}
case 42:
#line 408 "instrument.y"
{
		    yyval.instance = NULL;
		  ;
    break;}
case 43:
#line 412 "instrument.y"
{
		    yyval.instance = yyvsp[0].instance;
		  ;
    break;}
case 44:
#line 419 "instrument.y"
{
		    struct comp_inst *comp;
		    struct Symtab_entry *ent;

		    ent = symtab_lookup(comp_instances, yyvsp[0].string);
		    comp = NULL;
		    if(ent == NULL)
		      print_error("Reference to undefined component %s at line %d.\n",
				  yyvsp[0].string, instr_current_line);
		    else
		      comp = ent->val;
		    str_free(yyvsp[0].string);
		    yyval.instance = comp;
		  ;
    break;}
case 45:
#line 436 "instrument.y"
{
		    yyval.coords.x = yyvsp[-5].exp;
		    yyval.coords.y = yyvsp[-3].exp;
		    yyval.coords.z = yyvsp[-1].exp;
		  ;
    break;}
case 46:
#line 444 "instrument.y"
{
		    List_handle liter;
		    char *formal;
		    /* Check if this is an instrument parameter or not. */
		    /* ToDo: This will be inefficient if the number of
                       instrument parameters is really huge. */
		    liter = list_iterate(instrument_definition->formals);
		    while(formal = list_next(liter))
		    {
		      if(!strcasecmp(yyvsp[0].string, formal))
		      {
			/* It was an instrument parameter */
			yyval.exp = exp_id(yyvsp[0].string);
			goto found;
		      }
		    }
		    /* It was an external id. */
		    yyval.exp = exp_extern_id(yyvsp[0].string);
		  found:
		    str_free(yyvsp[0].string);
		  ;
    break;}
case 47:
#line 466 "instrument.y"
{
		    yyval.exp = exp_number(yyvsp[0].number);
		  ;
    break;}
case 48:
#line 470 "instrument.y"
{
		    /* Note: "EXTERN" is now obsolete and redundant. */
		    yyval.exp = exp_extern_id(yyvsp[0].string);
		    str_free(yyvsp[0].string);
		  ;
    break;}
case 49:
#line 476 "instrument.y"
{
		    yyval.exp = exp_string(yyvsp[0].string);
		    str_free(yyvsp[0].string);
		  ;
    break;}
case 50:
#line 483 "instrument.y"
{
		    yyvsp[-1].ccode->filename = instr_current_filename;
		    yyvsp[-1].ccode->quoted_filename = str_quote(instr_current_filename);
		    yyvsp[-1].ccode->linenum = yyvsp[-2].linenum;
		    yyval.ccode = yyvsp[-1].ccode;
		  ;
    break;}
case 51:
#line 492 "instrument.y"
{
		    yyval.ccode = codeblock_new();
		  ;
    break;}
case 52:
#line 497 "instrument.y"
{
		    list_add(yyvsp[-1].ccode->lines, yyvsp[0].string);
		    yyval.ccode = yyvsp[-1].ccode;
		  ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 498 "/usr/share/misc/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 504 "instrument.y"


/* Use own method for extending the parser stack, to remove bisons references
* to alloca(). This must appear in the .y file to pick up the right #defines.
*/
static Pool parser_pool = NULL;	/* Pool of parser allocations. */

int
mc_yyoverflow(char *msg,
	   short **ssp, int sssz,
	   YYSTYPE **vsp, int vssz,
#ifdef YYLSP_NEEDED
	   YYLTYPE **lsp, int lssz,
#endif
	   int *yystacksize
	   )
{
  short *nssp;
  YYSTYPE *nvsp;
#ifdef YYLSP_NEEDED
  YYLTYPE *nlsp;
#endif

  if(*yystacksize >= YYMAXDEPTH)
    fatal_error("%s\n", msg);
  *yystacksize *= 2;
  if(*yystacksize >= YYMAXDEPTH)
    *yystacksize = YYMAXDEPTH;

  nssp = pool_mem(parser_pool, *yystacksize*sizeof(*nssp));
  memcpy(nssp, *ssp, sssz);
  *ssp = nssp;
  nvsp = pool_mem(parser_pool, *yystacksize*sizeof(*nvsp));
  memcpy(nvsp, *vsp, vssz);
  *vsp = nvsp;
#ifdef YYLSP_NEEDED
  nlsp = pool_mem(parser_pool, *yystacksize*sizeof(*nlsp));
  memcpy(nlsp, *lsp, lssz);
  *lsp = nlsp;
#endif
  return 0;
}

static int mc_yyparse(void)
{
  int ret;
  Pool oldpool;

  oldpool = parser_pool;
  parser_pool = pool_create();
  ret = yyparse();
  pool_free(parser_pool);
  parser_pool = oldpool;
  return ret;
}
    
/* Name of the file currently being parsed. */
char *instr_current_filename = NULL;
/* Number of the line currently being parsed. */
int instr_current_line = 0;

/* Result from parsing instrument definition. */
struct instr_def *instrument_definition;

/* Map from names to component instances. */
Symtab comp_instances;

/* List of components, in the order they where declared in the instrument
   definition. */
List comp_instances_list;

/* Filename for outputting generated simulation program ('-' means stdin). */
static char *output_filename;

/* Map of already-read components. */
Symtab read_components = NULL;


/* Print a summary of the command usage and exit with error. */
static void
print_usage(void)
{
  fprintf(stderr, "Usage:\n"
	  "  mcstas [-o file] [-I dir1 ...] [-t] [-p] [-v] "
	  "[--no-main] [--no-runtime] file\n");
  exit(1);
}

/* Print McStas version and copyright. */
static void
print_version(void)
{
  printf("McStas version 1.1, March 31, 1999\n"
	  "Copyright (C) Risoe National Laboratory, 1997-1999\n"
	  "All rights reserved\n");
  exit(0);
}

/* Construct default filename for simulation output from instrument file
   name. Strip any leading directory path and trailing .instr, and add .c to
   the end. */
static char *
make_output_filename(char *name)
{
  char *p;
  int l;

  /* Find basename */
  p = strrchr(name, '/');
  if(p == NULL)
    p = name;			/* No initial path. */
  else
    p++;			/* Point past last '/' character. */

  /* Check for trailing .instr suffix. */
  l = strlen(p);
  if(l > 6 && !strcmp(&p[l - 6], ".instr"))
  {
    char *tmp = str_dup(p);
    tmp[l - 6] = '\0';
    p = str_cat(tmp, ".c", NULL);
    str_free(tmp);
  }
  else
    p = str_cat(p, ".c", NULL);
  return p;
}


static void
set_output_filename(char *name)
{
  output_filename = str_dup(name);
}

/* Parse command line options. */
static void
parse_command_line(int argc, char *argv[])
{
  int i;

  output_filename = NULL;
  instr_current_filename = NULL;
  instrument_definition->use_default_main = 1;
  instrument_definition->include_runtime = 1;
  instrument_definition->enable_trace = 0;
  instrument_definition->portable = 0;
  instrument_definition->polarised = 0;
  for(i = 1; i < argc; i++)
  {
    if(!strcmp("-o", argv[i]) && (i + 1) < argc)
      set_output_filename(argv[++i]);
    else if(!strncmp("-o", argv[i], 2))
      set_output_filename(&argv[i][2]);
    else if(!strcmp("--output-file", argv[i]) && (i + 1) < argc)
      set_output_filename(argv[++i]);
    else if(!strncmp("--output-file=", argv[i], 14))
      set_output_filename(&argv[i][14]);
    else if(!strcmp("-I", argv[i]) && (i + 1) < argc)
      add_search_dir(argv[++i]);
    else if(!strncmp("-I", argv[i], 2))
      add_search_dir(&argv[i][2]);
    else if(!strcmp("--search-dir", argv[i]) && (i + 1) < argc)
      add_search_dir(argv[++i]);
    else if(!strncmp("--search-dir=", argv[i], 13))
      add_search_dir(&argv[i][13]);
    else if(!strcmp("-t", argv[i]))
      instrument_definition->enable_trace = 1;
    else if(!strcmp("--trace", argv[i]))
      instrument_definition->enable_trace = 1;
    else if(!strcmp("-p", argv[i]))
      instrument_definition->portable = 1;
    else if(!strcmp("--portable", argv[i]))
      instrument_definition->portable = 1;
    else if(!strcmp("-v", argv[i]))
      print_version();
    else if(!strcmp("--version", argv[i]))
      print_version();
    else if(!strcmp("--no-main", argv[i]))
      instrument_definition->use_default_main = 0;
    else if(!strcmp("--no-runtime", argv[i]))
      instrument_definition->include_runtime = 0;
    else if(argv[i][0] != '-')
    {
      if(instr_current_filename != NULL)
	print_usage();		/* Multiple instruments given. */
      instr_current_filename = str_dup(argv[i]);
    }
    else
      print_usage();
  }

  /* Instrument filename must be given. */
  if(instr_current_filename == NULL)
    print_usage();
  /* If no '-o' option was given for INSTR.instr, default to INSTR.c  */
  if(output_filename == NULL)
    output_filename = make_output_filename(instr_current_filename);
}


int
main(int argc, char *argv[])
{
  FILE *file;
  int err;

#ifdef MAC
  argc = ccommand(&argv);
#endif

  yydebug = 0;			/* If 1, then bison gives verbose parser debug info. */

  palloc(instrument_definition); /* Allocate instrument def. structure. */
  parse_command_line(argc, argv);
  if(!strcmp(instr_current_filename, "-"))
  {
    instrument_definition->source = str_dup("<stdin>");
    file = fdopen(0, "r");	/* Lone '-' designates stdin. */
  }
  else
  {
    instrument_definition->source = str_dup(instr_current_filename);
    file = fopen(instr_current_filename, "r");
  }
  if(file == NULL)
    fatal_error("Instrument definition file `%s' not found\n",
		instr_current_filename);
  instr_current_line = 1;
  lex_new_file(file);
  read_components = symtab_create(); /* Create table of components. */
  err = mc_yyparse();
  fclose(file);
  if(err != 0 || error_encountered != 0)
    print_error("Errors encountered during parse.\n");
  else
    cogen(output_filename, instrument_definition);

  exit(0);
}


int
yyerror(char *s)
{
  print_error("%s at line %d.\n", s, instr_current_line);
}


/*******************************************************************************
* Check that all formal parameters of a component definition are unique.
*******************************************************************************/
void
check_comp_formals(List deflist, List setlist, char *compname)
{
  Symtab formals;
  char *formal;
  struct Symtab_entry *entry;
  List_handle liter;

  /* We check the uniqueness by adding all the formals to a symbol table with
     a dummy pointer value. Any formal parameter that already appears in the
     symbol table is an error. */
  formals = symtab_create();
  liter = list_iterate(deflist);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(formals, formal);
    if(entry != NULL)
      print_error("Definition parameter name %s is used multiple times "
		  "in component %s\n", formal, compname);
    else
      symtab_add(formals, formal, NULL);
  }
  list_iterate_end(liter);
  liter = list_iterate(setlist);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(formals, formal);
    if(entry != NULL)
      print_error("Setting parameter name %s is used multiple times "
		  "in component %s\n", formal, compname);
    else
      symtab_add(formals, formal, NULL);
  }
  list_iterate_end(liter);
  symtab_free(formals, NULL);
}


/*******************************************************************************
* Check that all formal parameters of an instrument definition are unique.
*******************************************************************************/
void
check_instrument_formals(List formallist, char *instrname)
{
  Symtab formals;
  char *formal;
  struct Symtab_entry *entry;
  List_handle liter;

  /* We check the uniqueness by adding all the formals to a symbol table with
     a dummy pointer value. Any formal parameter that already appears in the
     symbol table is an error. */
  formals = symtab_create();
  liter = list_iterate(formallist);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(formals, formal);
    if(entry != NULL)
      print_error("Instrument parameter name %s is used multiple times "
		  "in instrument %s\n", formal, instrname);
    else
      symtab_add(formals, formal, NULL);
  }
  list_iterate_end(liter);
  symtab_free(formals, NULL);
}


/*******************************************************************************
* Check the actual parameters to a component against the formal parameters.
*******************************************************************************/
void
comp_formals_actuals(struct comp_inst *comp, Symtab actuals)
{
  List_handle liter;
  char *formal;
  struct Symtab_entry *entry;
  Symtab defpar, setpar;
  Symtab_handle siter;
  
  /* We need to check
     1. That all actual parameters correspond to formal parameters.
     2. That all formal parameters are assigned actual parameters. */

  /* First check the formal parameters one by one. */
  defpar = symtab_create();
  setpar = symtab_create();
  liter = list_iterate(comp->def->def_par);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(actuals, formal);
    if(entry == NULL)
    {
      print_error("Unassigned definition parameter %s for component %s.\n",
		  formal, comp->name);
      symtab_add(defpar, formal, exp_number(0));
    } else {
      symtab_add(defpar, formal, entry->val);
    }
  }
  list_iterate_end(liter);
  liter = list_iterate(comp->def->set_par);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(actuals, formal);
    if(entry == NULL)
    {
      print_error("Unassigned setting parameter %s for component %s.\n",
		  formal, comp->name);
      symtab_add(setpar, formal, exp_number(0));
    } else {
      symtab_add(setpar, formal, entry->val);
    }
  }
  list_iterate_end(liter);

  /* Now check the actual parameters one by one. */
  siter = symtab_iterate(actuals);
  while(entry = symtab_next(siter))
  {
    if(symtab_lookup(defpar, entry->name) == NULL &&
       symtab_lookup(setpar, entry->name) == NULL)
    {
      print_error("Unmatched actual parameter %s for component %s.\n",
		  entry->name, comp->name);
    }
  }
  comp->defpar = defpar;
  comp->setpar = setpar;
}


/*******************************************************************************
* This is the main entry point for reading a component. When a component
* definition is needed, this function is called with the name of the
* component. A map of previously read components is maintained. If a
* component definition (struct comp)def) is found, it is returned. Otherwise
* an attempt is made to read the component definition from a file with the
* same name as the component with added file extension ".com".
* If for some reasons the component cannot be read, NULL is returned; else a
* pointer to a struct comp_def is returned. Since components definitions can
* be used multiple times, the returned structure is shared and should not be
* modified.
*******************************************************************************/
struct comp_def *
read_component(char *name)
{
  struct Symtab_entry *entry;
  
  /* Look for an existing definition for the component. */
  entry = symtab_lookup(read_components, name);
  if(entry != NULL)
  {
    return entry->val;		/* Return it if found. */
  }
  else
  {
    FILE *file;
    int err;
    
    /* Attempt to read definition from file components/<name>.com. */
    file = open_component_search(name);
    if(file == NULL)
    {
      print_error(
	"Cannot find file containing definition of component `%s'.\n", name);
      return NULL;
    }
    push_autoload(file);
    /* Note: the str_dup copy of the file name is stored in codeblocks, and
       must not be freed. */
    instr_current_filename = component_pathname;
    instr_current_line = 1;
    err = mc_yyparse();		/* Read definition from file. */
    if(err != 0)
      fatal_error("Errors encountered during autoload of component %s.\n",
		  name);
    fclose(file);
    /* Now check if the file contained the required component definition. */
    entry = symtab_lookup(read_components, name);
    if(entry != NULL)
    {
      return entry->val;
    }
    else
    {
      print_error("Definition of component %s not found.\n", name);
      return NULL;
    }
  }
}
