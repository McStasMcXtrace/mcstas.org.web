/*******************************************************************************
* Compile-time representation of component positions.
*
*	Project: Monte Carlo Simulation of Triple Axis Spectrometers
*	File name: position.c
*
*	Author: K.N.			Aug 12, 1997
*
*	$Id: position.c,v 1.2 1998/10/02 08:39:14 kn Exp $
*
*	$Log: position.c,v $
*	Revision 1.2  1998/10/02 08:39:14  kn
*	Fixed header comment.
*
*	Revision 1.1  1997/08/13 09:15:57  kn
*	Initial revision
*
*
* Copyright (C) Risoe National Laboratory, 1997-1998, All rights reserved
*******************************************************************************/

#include "mcstas.h"

