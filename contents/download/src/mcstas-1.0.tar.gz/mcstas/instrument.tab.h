typedef union {
  double number;
  char *string;
  struct code_block *ccode;	/* User-supplied C code block. */
  CExp exp;			/* Expression datatype (for arguments). */
  int linenum;			/* Starting line number for code block. */
  Coords_exp coords;		/* Coordinates for location or rotation. */
  List formals;			/* List of formal parameters. */
  Symtab actuals;		/* Values for formal parameters. */
  struct {List def, set, out, state;} parms;	/* Parameter lists. */
  struct instr_def *instrument;	/* Instrument definition. */
  struct comp_inst *instance;	/* Component instance. */
  struct comp_place place;	/* Component place. */
  struct comp_orientation ori;	/* Component orientation. */
} YYSTYPE;
#define	TOK_RESTRICTED	258
#define	TOK_GENERAL	259
#define	TOK_ABSOLUTE	260
#define	TOK_AT	261
#define	TOK_COMPONENT	262
#define	TOK_DECLARE	263
#define	TOK_DEFINE	264
#define	TOK_DEFINITION	265
#define	TOK_END	266
#define	TOK_FINALLY	267
#define	TOK_EXTERN	268
#define	TOK_INITIALIZE	269
#define	TOK_INSTRUMENT	270
#define	TOK_OUTPUT	271
#define	TOK_PARAMETERS	272
#define	TOK_RELATIVE	273
#define	TOK_ROTATED	274
#define	TOK_SETTING	275
#define	TOK_STATE	276
#define	TOK_TRACE	277
#define	TOK_ID	278
#define	TOK_STRING	279
#define	TOK_NUMBER	280
#define	TOK_CODE_START	281
#define	TOK_CODE_END	282
#define	TOK_CODE_LINE	283
#define	TOK_INVALID	284

