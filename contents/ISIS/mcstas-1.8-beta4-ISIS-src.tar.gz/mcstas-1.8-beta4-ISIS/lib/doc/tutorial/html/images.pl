# LaTeX2HTML 2002-2-1 (1.70)
# Associate images original text with physical files.


$key = q/n=1;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img22.png"
 ALT="$n=1$">|; 

$key = q/k=frac{2pi}{nlambda};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="53" HEIGHT="34" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="$k=\frac{2\pi}{n\lambda}$">|; 

$key = q/vec{Q};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$\vec{Q}$">|; 

$key = q/0.1^circ;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="32" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="$0.1^\circ$">|; 

$key = q/Theta;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="16" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img26.png"
 ALT="$\Theta$">|; 

$key = q/includegraphics[width=12cm]{picsslashinstr.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="545" HEIGHT="411" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img18.png"
 ALT="\includegraphics[width=12cm]{pics/instr.eps}">|; 

$key = q/^{-1};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img21.png"
 ALT="$^{-1}$">|; 

$key = q/{displaymath}nlambda=2dsin(theta),{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\begin{displaymath}n\lambda=2d\sin(\theta),\end{displaymath}">|; 

$key = q/lambda;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="13" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$\lambda$">|; 

$key = q/includegraphics[width=6cm]{picsslashmono.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="264" HEIGHT="218" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img19.png"
 ALT="\includegraphics[width=6cm]{pics/mono.eps}">|; 

$key = q/lambda_0;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="$\lambda_0$">|; 

$key = q/z;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$z$">|; 

$key = q/{displaymath}Q=|vec{Q}|=frac{2pi}{d}.{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="101" HEIGHT="38" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\begin{displaymath}Q=\vert\vec{Q}\vert=\frac{2\pi}{d}.\end{displaymath}">|; 

$key = q/Q=1.8734;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="82" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img20.png"
 ALT="$Q=1.8734$">|; 

$key = q/Q;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="17" HEIGHT="29" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img23.png"
 ALT="$Q$">|; 

$key = q/2^circ;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$2^\circ$">|; 

$key = q/I;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$I$">|; 

$key = q/{displaymath}Q=2ksin(theta),{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="97" HEIGHT="28" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\begin{displaymath}Q=2k\sin(\theta),\end{displaymath}">|; 

$key = q/d;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$d$">|; 

$key = q/includegraphics[width=9cm]{picsslashbragg.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="406" HEIGHT="272" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\includegraphics[width=9cm]{pics/bragg.eps}">|; 

$key = q/n;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="14" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$n$">|; 

$key = q/n=2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="43" HEIGHT="13" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img24.png"
 ALT="$n=2$">|; 

$key = q/theta;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$\theta$">|; 

$key = q/N;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$N$">|; 

$key = q/^circ;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="15" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img25.png"
 ALT="$^\circ$">|; 

$key = q/y;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="28" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img17.png"
 ALT="$y$">|; 

1;

