# LaTeX2HTML 2002-2-1 (1.70)
# Associate internals original text with physical files.


$key = q/cite_Manual/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_Websites/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_McStas0/;
$ref_files{$key} = "$dir".q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/instr.eps/;
$ref_files{$key} = "$dir".q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/mono.eps/;
$ref_files{$key} = "$dir".q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/bragg.eps/;
$ref_files{$key} = "$dir".q|node4.html|; 
$noresave{$key} = "$nosave";

1;

