/* A Bison parser, made by GNU Bison 1.875a.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_RESTRICTED = 258,
     TOK_GENERAL = 259,
     TOK_ABSOLUTE = 260,
     TOK_AT = 261,
     TOK_COMPONENT = 262,
     TOK_DECLARE = 263,
     TOK_DEFINE = 264,
     TOK_DEFINITION = 265,
     TOK_END = 266,
     TOK_FINALLY = 267,
     TOK_EXTERN = 268,
     TOK_INITIALIZE = 269,
     TOK_INSTRUMENT = 270,
     TOK_MCDISPLAY = 271,
     TOK_OUTPUT = 272,
     TOK_PARAMETERS = 273,
     TOK_POLARISATION = 274,
     TOK_RELATIVE = 275,
     TOK_ROTATED = 276,
     TOK_PREVIOUS = 277,
     TOK_SETTING = 278,
     TOK_STATE = 279,
     TOK_TRACE = 280,
     TOK_SHARE = 281,
     TOK_EXTEND = 282,
     TOK_GROUP = 283,
     TOK_SAVE = 284,
     TOK_NEXUS = 285,
     TOK_DICTFILE = 286,
     TOK_HDF = 287,
     TOK_ID = 288,
     TOK_STRING = 289,
     TOK_NUMBER = 290,
     TOK_CTOK = 291,
     TOK_CODE_START = 292,
     TOK_CODE_END = 293,
     TOK_CODE_LINE = 294,
     TOK_INVALID = 295
   };
#endif
#define TOK_RESTRICTED 258
#define TOK_GENERAL 259
#define TOK_ABSOLUTE 260
#define TOK_AT 261
#define TOK_COMPONENT 262
#define TOK_DECLARE 263
#define TOK_DEFINE 264
#define TOK_DEFINITION 265
#define TOK_END 266
#define TOK_FINALLY 267
#define TOK_EXTERN 268
#define TOK_INITIALIZE 269
#define TOK_INSTRUMENT 270
#define TOK_MCDISPLAY 271
#define TOK_OUTPUT 272
#define TOK_PARAMETERS 273
#define TOK_POLARISATION 274
#define TOK_RELATIVE 275
#define TOK_ROTATED 276
#define TOK_PREVIOUS 277
#define TOK_SETTING 278
#define TOK_STATE 279
#define TOK_TRACE 280
#define TOK_SHARE 281
#define TOK_EXTEND 282
#define TOK_GROUP 283
#define TOK_SAVE 284
#define TOK_NEXUS 285
#define TOK_DICTFILE 286
#define TOK_HDF 287
#define TOK_ID 288
#define TOK_STRING 289
#define TOK_NUMBER 290
#define TOK_CTOK 291
#define TOK_CODE_START 292
#define TOK_CODE_END 293
#define TOK_CODE_LINE 294
#define TOK_INVALID 295




#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 44 "instrument.y"
typedef union YYSTYPE {
  char *number;
  char *string;
  struct code_block *ccode;	/* User-supplied C code block */
  CExp exp;			/* Expression datatype (for arguments) */
  int linenum;			/* Starting line number for code block */
  Coords_exp coords;		/* Coordinates for location or rotation */
  List formals;			/* List of formal parameters */
  List iformals;		/* List of formal instrument parameters */
  List comp_iformals;		/* List of formal comp. input parameters */
  struct instr_formal *iformal;	/* Single formal instrument parameter */
  struct comp_iformal *cformal;	/* Single formal component input parameter */
  Symtab actuals;		/* Values for formal parameters */
  char **polform;		/* Polarisation state formal parameter */
  struct {List def, set, out, state;
	  char **polarisation;} parms;	/* Parameter lists */
  struct instr_def *instrument;	/* Instrument definition */
  struct comp_inst *instance;	/* Component instance */
  struct comp_place place;	/* Component place */
  struct comp_orientation ori;	/* Component orientation */
  struct NXDinfo *nxdinfo;	/* Info for NeXus dictionary interface */
  struct group_inst *groupinst;
} YYSTYPE;
/* Line 1240 of yacc.c.  */
#line 141 "instrument.tab.h"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif





