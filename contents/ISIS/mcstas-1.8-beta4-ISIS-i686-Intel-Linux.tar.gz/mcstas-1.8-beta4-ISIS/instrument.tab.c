/* A Bison parser, made by GNU Bison 1.875a.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     TOK_RESTRICTED = 258,
     TOK_GENERAL = 259,
     TOK_ABSOLUTE = 260,
     TOK_AT = 261,
     TOK_COMPONENT = 262,
     TOK_DECLARE = 263,
     TOK_DEFINE = 264,
     TOK_DEFINITION = 265,
     TOK_END = 266,
     TOK_FINALLY = 267,
     TOK_EXTERN = 268,
     TOK_INITIALIZE = 269,
     TOK_INSTRUMENT = 270,
     TOK_MCDISPLAY = 271,
     TOK_OUTPUT = 272,
     TOK_PARAMETERS = 273,
     TOK_POLARISATION = 274,
     TOK_RELATIVE = 275,
     TOK_ROTATED = 276,
     TOK_PREVIOUS = 277,
     TOK_SETTING = 278,
     TOK_STATE = 279,
     TOK_TRACE = 280,
     TOK_SHARE = 281,
     TOK_EXTEND = 282,
     TOK_GROUP = 283,
     TOK_SAVE = 284,
     TOK_NEXUS = 285,
     TOK_DICTFILE = 286,
     TOK_HDF = 287,
     TOK_ID = 288,
     TOK_STRING = 289,
     TOK_NUMBER = 290,
     TOK_CTOK = 291,
     TOK_CODE_START = 292,
     TOK_CODE_END = 293,
     TOK_CODE_LINE = 294,
     TOK_INVALID = 295
   };
#endif
#define TOK_RESTRICTED 258
#define TOK_GENERAL 259
#define TOK_ABSOLUTE 260
#define TOK_AT 261
#define TOK_COMPONENT 262
#define TOK_DECLARE 263
#define TOK_DEFINE 264
#define TOK_DEFINITION 265
#define TOK_END 266
#define TOK_FINALLY 267
#define TOK_EXTERN 268
#define TOK_INITIALIZE 269
#define TOK_INSTRUMENT 270
#define TOK_MCDISPLAY 271
#define TOK_OUTPUT 272
#define TOK_PARAMETERS 273
#define TOK_POLARISATION 274
#define TOK_RELATIVE 275
#define TOK_ROTATED 276
#define TOK_PREVIOUS 277
#define TOK_SETTING 278
#define TOK_STATE 279
#define TOK_TRACE 280
#define TOK_SHARE 281
#define TOK_EXTEND 282
#define TOK_GROUP 283
#define TOK_SAVE 284
#define TOK_NEXUS 285
#define TOK_DICTFILE 286
#define TOK_HDF 287
#define TOK_ID 288
#define TOK_STRING 289
#define TOK_NUMBER 290
#define TOK_CTOK 291
#define TOK_CODE_START 292
#define TOK_CODE_END 293
#define TOK_CODE_LINE 294
#define TOK_INVALID 295




/* Copy the first part of user declarations.  */
#line 24 "instrument.y"

#include <math.h>
#include <string.h>
#include <stdio.h>

#include "mcstas.h"

#define YYERROR_VERBOSE 1
#define YYDEBUG 1



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 44 "instrument.y"
typedef union YYSTYPE {
  char *number;
  char *string;
  struct code_block *ccode;	/* User-supplied C code block */
  CExp exp;			/* Expression datatype (for arguments) */
  int linenum;			/* Starting line number for code block */
  Coords_exp coords;		/* Coordinates for location or rotation */
  List formals;			/* List of formal parameters */
  List iformals;		/* List of formal instrument parameters */
  List comp_iformals;		/* List of formal comp. input parameters */
  struct instr_formal *iformal;	/* Single formal instrument parameter */
  struct comp_iformal *cformal;	/* Single formal component input parameter */
  Symtab actuals;		/* Values for formal parameters */
  char **polform;		/* Polarisation state formal parameter */
  struct {List def, set, out, state;
	  char **polarisation;} parms;	/* Parameter lists */
  struct instr_def *instrument;	/* Instrument definition */
  struct comp_inst *instance;	/* Component instance */
  struct comp_place place;	/* Component place */
  struct comp_orientation ori;	/* Component orientation */
  struct NXDinfo *nxdinfo;	/* Info for NeXus dictionary interface */
  struct group_inst *groupinst;
} YYSTYPE;
/* Line 191 of yacc.c.  */
#line 192 "instrument.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 214 of yacc.c.  */
#line 204 "instrument.tab.c"

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# if YYSTACK_USE_ALLOCA
#  define YYSTACK_ALLOC alloca
# else
#  ifndef YYSTACK_USE_ALLOCA
#   if defined (alloca) || defined (_ALLOCA_H)
#    define YYSTACK_ALLOC alloca
#   else
#    ifdef __GNUC__
#     define YYSTACK_ALLOC __builtin_alloca
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
# else
#  if defined (__STDC__) || defined (__cplusplus)
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   define YYSIZE_T size_t
#  endif
#  define YYSTACK_ALLOC malloc
#  define YYSTACK_FREE free
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short) + sizeof (YYSTYPE))				\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  register YYSIZE_T yyi;		\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  7
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   224

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  50
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  56
/* YYNRULES -- Number of rules. */
#define YYNRULES  112
/* YYNRULES -- Number of states. */
#define YYNSTATES  203

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   295

#define YYTRANSLATE(YYX) 						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      41,    43,    44,     2,    42,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    45,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    46,     2,    47,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    48,     2,    49,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short yyprhs[] =
{
       0,     0,     3,     7,    10,    11,    14,    27,    33,    34,
      38,    39,    43,    44,    48,    52,    53,    63,    67,    68,
      70,    72,    76,    79,    83,    85,    89,    94,   100,   101,
     114,   118,   119,   121,   123,   127,   130,   134,   136,   140,
     145,   151,   152,   155,   156,   159,   160,   163,   164,   169,
     170,   174,   175,   179,   182,   183,   186,   187,   190,   191,
     194,   197,   198,   201,   211,   215,   216,   218,   220,   224,
     228,   229,   231,   235,   241,   245,   246,   250,   252,   255,
     261,   264,   265,   268,   270,   272,   280,   281,   284,   285,
     288,   289,   293,   295,   298,   300,   302,   304,   306,   308,
     310,   314,   317,   321,   324,   328,   331,   333,   336,   338,
     340,   344,   345
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const yysigned_char yyrhs[] =
{
      51,     0,    -1,     4,    52,    64,    -1,     3,    53,    -1,
      -1,    52,    53,    -1,     9,     7,    33,    54,    72,    70,
      71,    76,    77,    78,    79,    11,    -1,    55,    56,    57,
      58,    59,    -1,    -1,    10,    18,    60,    -1,    -1,    23,
      18,    60,    -1,    -1,    17,    18,    83,    -1,    24,    18,
      83,    -1,    -1,    19,    18,    41,    33,    42,    33,    42,
      33,    43,    -1,    41,    61,    43,    -1,    -1,    62,    -1,
      63,    -1,    62,    42,    63,    -1,    33,    33,    -1,    33,
      44,    33,    -1,    33,    -1,    33,    45,    97,    -1,    33,
      33,    45,    97,    -1,    33,    44,    33,    45,    97,    -1,
      -1,     9,    15,    33,    66,    65,    70,    71,    73,    80,
      77,    78,    11,    -1,    41,    67,    43,    -1,    -1,    68,
      -1,    69,    -1,    68,    42,    69,    -1,    33,    33,    -1,
      33,    44,    33,    -1,    33,    -1,    33,    45,    97,    -1,
      33,    33,    45,    97,    -1,    33,    44,    33,    45,    97,
      -1,    -1,     8,   104,    -1,    -1,    14,   104,    -1,    -1,
      26,   104,    -1,    -1,    73,    30,    74,    75,    -1,    -1,
      74,    31,    34,    -1,    -1,    75,    32,    35,    -1,    25,
     104,    -1,    -1,    29,   104,    -1,    -1,    12,   104,    -1,
      -1,    16,   104,    -1,    25,    81,    -1,    -1,    81,    82,
      -1,     7,    33,    45,    33,    86,    89,    90,    92,    96,
      -1,    41,    84,    43,    -1,    -1,    85,    -1,    33,    -1,
      85,    42,    33,    -1,    41,    87,    43,    -1,    -1,    88,
      -1,    33,    45,    97,    -1,    88,    42,    33,    45,    97,
      -1,     6,    95,    91,    -1,    -1,    21,    95,    91,    -1,
       5,    -1,    20,    22,    -1,    20,    22,    41,    35,    43,
      -1,    20,    94,    -1,    -1,    28,    93,    -1,    33,    -1,
      33,    -1,    41,    97,    42,    97,    42,    97,    43,    -1,
      -1,    27,   104,    -1,    -1,    98,   100,    -1,    -1,    13,
      99,    33,    -1,   101,    -1,   100,   101,    -1,    33,    -1,
      35,    -1,    34,    -1,    36,    -1,    45,    -1,    44,    -1,
      41,   102,    43,    -1,    41,    43,    -1,    46,   102,    47,
      -1,    46,    47,    -1,    48,   102,    49,    -1,    48,    49,
      -1,   103,    -1,   102,   103,    -1,   101,    -1,    42,    -1,
      37,   105,    38,    -1,    -1,   105,    39,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short yyrline[] =
{
       0,   132,   132,   133,   136,   137,   140,   169,   181,   184,
     191,   194,   201,   204,   210,   217,   220,   231,   238,   241,
     247,   252,   259,   277,   291,   300,   310,   330,   349,   348,
     371,   378,   381,   387,   392,   399,   417,   431,   440,   450,
     470,   488,   491,   498,   501,   509,   512,   520,   527,   546,
     549,   555,   558,   564,   571,   574,   581,   584,   591,   594,
     600,   603,   609,   637,   669,   677,   680,   686,   691,   698,
     705,   708,   714,   720,   728,   736,   740,   749,   753,   762,
     776,   784,   787,   793,   813,   830,   840,   843,   851,   851,
     857,   857,   868,   872,   882,   904,   909,   914,   919,   923,
     927,   936,   944,   953,   961,   970,   981,   985,   993,   997,
    1003,  1013,  1017
};
#endif

#if YYDEBUG || YYERROR_VERBOSE
/* YYTNME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "TOK_RESTRICTED", "TOK_GENERAL", 
  "\"ABSOLUTE\"", "\"AT\"", "\"COMPONENT\"", "\"DECLARE\"", "\"DEFINE\"", 
  "\"DEFINITION\"", "\"END\"", "\"FINALLY\"", "\"EXTERN\"", 
  "\"INITIALIZE\"", "\"INSTRUMENT\"", "\"MCDISPLAY\"", "\"OUTPUT\"", 
  "\"PARAMETERS\"", "\"POLARISATION\"", "\"RELATIVE\"", "\"ROTATED\"", 
  "\"PREVIOUS\"", "\"SETTING\"", "\"STATE\"", "\"TRACE\"", "\"SHARE\"", 
  "\"EXTEND\"", "\"GROUP\"", "\"SAVE\"", "\"NEXUS\"", "\"DICTFILE\"", 
  "\"HDF\"", "TOK_ID", "TOK_STRING", "TOK_NUMBER", "TOK_CTOK", 
  "TOK_CODE_START", "TOK_CODE_END", "TOK_CODE_LINE", "TOK_INVALID", "'('", 
  "','", "')'", "'*'", "'='", "'['", "']'", "'{'", "'}'", "$accept", 
  "main", "compdefs", "compdef", "parameters", "def_par", "set_par", 
  "out_par", "state_par", "polarisation_par", "comp_iformallist", 
  "comp_iformals", "comp_iformals1", "comp_iformal", "instrument", "@1", 
  "instrpar_list", "instr_formals", "instr_formals1", "instr_formal", 
  "declare", "initialize", "share", "nexus", "dictfile", "hdfversion", 
  "trace", "save", "finally", "mcdisplay", "instr_trace", "complist", 
  "component", "formallist", "formals", "formals1", "actuallist", 
  "actuals", "actuals1", "place", "orientation", "reference", "groupref", 
  "groupdef", "compref", "coords", "extend", "exp", "@2", "@3", "topexp", 
  "topatexp", "genexp", "genatexp", "codeblock", "code", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,    40,    44,    41,    42,    61,    91,    93,   123,   125
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,    50,    51,    51,    52,    52,    53,    54,    55,    55,
      56,    56,    57,    57,    58,    59,    59,    60,    61,    61,
      62,    62,    63,    63,    63,    63,    63,    63,    65,    64,
      66,    67,    67,    68,    68,    69,    69,    69,    69,    69,
      69,    70,    70,    71,    71,    72,    72,    73,    73,    74,
      74,    75,    75,    76,    77,    77,    78,    78,    79,    79,
      80,    81,    81,    82,    83,    84,    84,    85,    85,    86,
      87,    87,    88,    88,    89,    90,    90,    91,    91,    91,
      91,    92,    92,    93,    94,    95,    96,    96,    98,    97,
      99,    97,   100,   100,   101,   101,   101,   101,   101,   101,
     101,   101,   101,   101,   101,   101,   102,   102,   103,   103,
     104,   105,   105
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     3,     2,     0,     2,    12,     5,     0,     3,
       0,     3,     0,     3,     3,     0,     9,     3,     0,     1,
       1,     3,     2,     3,     1,     3,     4,     5,     0,    12,
       3,     0,     1,     1,     3,     2,     3,     1,     3,     4,
       5,     0,     2,     0,     2,     0,     2,     0,     4,     0,
       3,     0,     3,     2,     0,     2,     0,     2,     0,     2,
       2,     0,     2,     9,     3,     0,     1,     1,     3,     3,
       0,     1,     3,     5,     3,     0,     3,     1,     2,     5,
       2,     0,     2,     1,     1,     7,     0,     2,     0,     2,
       0,     3,     1,     2,     1,     1,     1,     1,     1,     1,
       3,     2,     3,     2,     3,     2,     1,     2,     1,     1,
       3,     0,     2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       0,     0,     4,     0,     0,     3,     0,     1,     0,     0,
       5,     2,     8,     0,     0,    45,    10,     0,     0,     0,
      41,     0,    12,    31,    28,    18,     9,   111,    46,     0,
      43,     0,     0,     0,    37,     0,    32,    33,    41,    24,
       0,    19,    20,     0,    42,     0,     0,    11,     0,     0,
      15,    35,     0,    88,    30,     0,    43,    22,     0,    88,
      17,     0,   110,   112,    44,     0,    54,    65,    13,     0,
       0,     7,    88,    36,    90,    38,     0,    34,    47,    88,
      23,    25,    21,    53,     0,    56,    67,     0,    66,    14,
       0,    39,    88,     0,    94,    96,    95,    97,     0,    99,
      98,     0,     0,    89,    92,     0,    26,    88,    55,     0,
      58,    64,     0,     0,    40,    91,   109,   101,   108,     0,
     106,   103,     0,   105,     0,    93,    61,    49,    54,    27,
      57,     0,     0,    68,     0,   100,   107,   102,   104,    60,
      51,    56,    59,     6,     0,     0,    62,     0,    48,     0,
       0,     0,    50,     0,    29,     0,     0,    52,     0,     0,
      16,    70,     0,     0,     0,    71,     0,    75,    88,    69,
       0,    88,     0,     0,    81,    72,     0,     0,    77,     0,
      74,     0,     0,    86,    88,    88,    78,    84,    80,    76,
      83,    82,     0,    63,    73,     0,     0,    87,    88,     0,
       0,    79,    85
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short yydefgoto[] =
{
      -1,     3,     6,     5,    15,    16,    22,    33,    50,    71,
      26,    40,    41,    42,    11,    38,    24,    35,    36,    37,
      30,    46,    20,   105,   140,   148,    66,    85,   110,   132,
     128,   139,   146,    68,    87,    88,   162,   164,   165,   167,
     174,   180,   183,   191,   188,   172,   193,    75,    76,    93,
     103,   118,   119,   120,    28,    43
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -75
static const short yypact[] =
{
       0,    16,   -75,    37,    47,   -75,    35,   -75,    24,    -2,
     -75,   -75,    50,    31,    51,    44,    48,    36,    38,    41,
      64,    69,    72,    57,   -75,    58,   -75,   -75,   -75,    41,
      82,    38,    79,    74,   -21,    56,    66,   -75,    64,    23,
      68,    73,   -75,   -11,   -75,    41,    91,   -75,    76,   100,
     105,    80,    86,   121,   -75,    57,    82,    96,   109,   121,
     -75,    58,   -75,   -75,   -75,    41,   114,   113,   -75,    76,
     134,   -75,   121,   108,   -75,   -75,   -26,   -75,   -75,   121,
     110,   -75,   -75,   -75,    41,   142,   -75,   115,   117,   -75,
     116,   -75,   121,   123,   -75,   -75,   -75,   -75,    40,   -75,
     -75,    59,    -3,   -26,   -75,    10,   -75,   121,   -75,    41,
     144,   -75,   128,   129,   -75,   -75,   -75,   -75,   -75,    87,
     -75,   -75,   103,   -75,    17,   -75,   -75,   -75,   114,   -75,
     -75,    41,   153,   -75,   124,   -75,   -75,   -75,   -75,   158,
     136,   142,   -75,   -75,   135,   137,   -75,   138,   139,   162,
     127,   130,   -75,   141,   -75,   145,   146,   -75,   131,   140,
     -75,   147,   171,   143,   148,   150,   149,   161,   121,   -75,
     151,   121,     6,   149,   155,   -75,   152,   154,   -75,   -16,
     -75,     6,   156,   159,   121,   121,   157,   -75,   -75,   -75,
     -75,   -75,    41,   -75,   -75,   160,   164,   -75,   121,   163,
     165,   -75,   -75
};

/* YYPGOTO[NTERM-NUM].  */
static const short yypgoto[] =
{
     -75,   -75,   -75,   179,   -75,   -75,   -75,   -75,   -75,   -75,
     169,   -75,   -75,   126,   -75,   -75,   -75,   -75,   -75,   166,
     167,   168,   -75,   -75,   -75,   -75,   -75,    65,    53,   -75,
     -75,   -75,   -75,   132,   -75,   -75,   -75,   -75,   -75,   -75,
     -75,    14,   -75,   -75,   -75,    30,   -75,   -58,   -75,   -75,
     -75,   -74,   -54,   -10,   -29,   -75
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -1
static const unsigned char yytable[] =
{
      44,    81,   104,     1,     2,     8,   186,    94,    95,    96,
      97,   178,    51,    13,    91,    98,    64,   187,    99,   100,
     101,   106,   102,    52,    53,     4,   179,    62,    63,   125,
      94,    95,    96,    97,   114,   126,    83,     7,    98,   116,
     127,    99,   100,   101,     9,   102,   123,   122,   124,   129,
      94,    95,    96,    97,     8,   108,    57,    12,    98,   116,
      14,    99,   100,   101,    17,   102,   138,    58,    59,    18,
      19,    21,    29,    94,    95,    96,    97,    23,    27,    25,
     130,    98,   116,   117,    99,   100,   101,    31,   102,    32,
      34,    39,    94,    95,    96,    97,    45,    48,    49,    54,
      98,   116,   142,    99,   100,   101,   121,   102,    55,   136,
     175,    60,   136,   177,   136,    61,    65,    67,    69,    73,
      94,    95,    96,    97,    70,    72,   194,   195,    98,   116,
     135,    99,   100,   101,    74,   102,    94,    95,    96,    97,
     200,    79,    80,    84,    98,   116,    86,    99,   100,   101,
     137,   102,    90,    92,   109,   107,   115,   113,   111,   112,
     131,   133,   134,   197,   143,   145,   144,   147,   150,   155,
     151,   153,   152,   154,   160,   156,   157,   166,   158,   159,
     163,   161,   173,   182,   176,    10,   192,    82,   168,   190,
     171,   169,   170,   141,   149,   189,   185,   184,   196,   199,
      47,    89,   198,   181,     0,    56,   201,     0,   202,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    77,     0,     0,    78
};

static const short yycheck[] =
{
      29,    59,    76,     3,     4,     7,    22,    33,    34,    35,
      36,     5,    33,    15,    72,    41,    45,    33,    44,    45,
      46,    79,    48,    44,    45,     9,    20,    38,    39,   103,
      33,    34,    35,    36,    92,    25,    65,     0,    41,    42,
      30,    44,    45,    46,     9,    48,    49,   101,   102,   107,
      33,    34,    35,    36,     7,    84,    33,    33,    41,    42,
      10,    44,    45,    46,    33,    48,    49,    44,    45,    18,
      26,    23,     8,    33,    34,    35,    36,    41,    37,    41,
     109,    41,    42,    43,    44,    45,    46,    18,    48,    17,
      33,    33,    33,    34,    35,    36,    14,    18,    24,    43,
      41,    42,   131,    44,    45,    46,    47,    48,    42,   119,
     168,    43,   122,   171,   124,    42,    25,    41,    18,    33,
      33,    34,    35,    36,    19,    45,   184,   185,    41,    42,
      43,    44,    45,    46,    13,    48,    33,    34,    35,    36,
     198,    45,    33,    29,    41,    42,    33,    44,    45,    46,
      47,    48,    18,    45,    12,    45,    33,    41,    43,    42,
      16,    33,    33,   192,    11,     7,    42,    31,    33,    42,
      33,    32,    34,    11,    43,    45,    35,     6,    33,    33,
      33,    41,    21,    28,    33,     6,    27,    61,    45,    33,
      41,    43,    42,   128,   141,   181,    42,    45,    41,    35,
      31,    69,    42,   173,    -1,    38,    43,    -1,    43,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    55,    -1,    -1,    56
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,     3,     4,    51,     9,    53,    52,     0,     7,     9,
      53,    64,    33,    15,    10,    54,    55,    33,    18,    26,
      72,    23,    56,    41,    66,    41,    60,    37,   104,     8,
      70,    18,    17,    57,    33,    67,    68,    69,    65,    33,
      61,    62,    63,   105,   104,    14,    71,    60,    18,    24,
      58,    33,    44,    45,    43,    42,    70,    33,    44,    45,
      43,    42,    38,    39,   104,    25,    76,    41,    83,    18,
      19,    59,    45,    33,    13,    97,    98,    69,    71,    45,
      33,    97,    63,   104,    29,    77,    33,    84,    85,    83,
      18,    97,    45,    99,    33,    34,    35,    36,    41,    44,
      45,    46,    48,   100,   101,    73,    97,    45,   104,    12,
      78,    43,    42,    41,    97,    33,    42,    43,   101,   102,
     103,    47,   102,    49,   102,   101,    25,    30,    80,    97,
     104,    16,    79,    33,    33,    43,   103,    47,    49,    81,
      74,    77,   104,    11,    42,     7,    82,    31,    75,    78,
      33,    33,    34,    32,    11,    42,    45,    35,    33,    33,
      43,    41,    86,    33,    87,    88,     6,    89,    45,    43,
      42,    41,    95,    21,    90,    97,    33,    97,     5,    20,
      91,    95,    28,    92,    45,    42,    22,    33,    94,    91,
      33,    93,    27,    96,    97,    97,    41,   104,    42,    35,
      97,    43,    43
};

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# if defined (__STDC__) || defined (__cplusplus)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# endif
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrlab1


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { 								\
      yyerror ("syntax error: cannot back up");\
      YYERROR;							\
    }								\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

/* YYLLOC_DEFAULT -- Compute the default location (before the actions
   are run).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)         \
  Current.first_line   = Rhs[1].first_line;      \
  Current.first_column = Rhs[1].first_column;    \
  Current.last_line    = Rhs[N].last_line;       \
  Current.last_column  = Rhs[N].last_column;
#endif

/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (&yylval, YYLEX_PARAM)
#else
# define YYLEX yylex (&yylval)
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YYDSYMPRINT(Args)			\
do {						\
  if (yydebug)					\
    yysymprint Args;				\
} while (0)

# define YYDSYMPRINTF(Title, Token, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr, 					\
                  Token, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (cinluded).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short *bottom, short *top)
#else
static void
yy_stack_print (bottom, top)
    short *bottom;
    short *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned int yylineno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %u), ",
             yyrule - 1, yylineno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname [yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname [yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YYDSYMPRINT(Args)
# define YYDSYMPRINTF(Title, Token, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   SIZE_MAX < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#if YYMAXDEPTH == 0
# undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  register const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  register char *yyd = yydest;
  register const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

#endif /* !YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    {
      YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
# ifdef YYPRINT
      YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
    }
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yytype, yyvaluep)
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */






/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  /* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;

  register int yystate;
  register int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short	yyssa[YYINITDEPTH];
  short *yyss = yyssa;
  register short *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  register YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow ("parser stack overflow",
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyoverflowlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyoverflowlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyoverflowlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YYDSYMPRINTF ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */
  YYDPRINTF ((stderr, "Shifting token %s, ", yytname[yytoken]));

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 6:
#line 141 "instrument.y"
    {
		    struct comp_def *c;
		    palloc(c);
		    c->name = yyvsp[-9].string;
        /* ADD: E. Farhi, Aug 14th, 2002 */
        c->source = str_quote(instr_current_filename);
		    c->def_par = yyvsp[-8].parms.def;
		    c->set_par = yyvsp[-8].parms.set;
		    c->out_par = yyvsp[-8].parms.out;
		    c->state_par = yyvsp[-8].parms.state;
		    c->polarisation_par = yyvsp[-8].parms.polarisation;
        c->share_code = yyvsp[-7].ccode;  /* ADD: E. Farhi Sep 20th, 2001 */
		    c->decl_code = yyvsp[-6].ccode;  /* MOD: E. Farhi Sep 20th, 2001, shifted param numbs */
		    c->init_code = yyvsp[-5].ccode;
		    c->trace_code = yyvsp[-4].ccode;
        c->save_code = yyvsp[-3].ccode;  /* ADD: E. Farhi Aug 25th, 2002+shifted indexes */
		    c->finally_code = yyvsp[-2].ccode;
		    c->mcdisplay_code = yyvsp[-1].ccode;
        c->comp_inst_number = 0; /* ADD: E. Farhi Sep 20th, 2001 */

		    /* Check definition and setting params for uniqueness */
		    check_comp_formals(c->def_par, c->set_par, c->name);
		    /* Put component definition in table. */
		    symtab_add(read_components, c->name, c);
        if (verbose) fprintf(stderr, "Embedding component %s\n", c->source);
		  ;}
    break;

  case 7:
#line 170 "instrument.y"
    {
		    yyval.parms.def = yyvsp[-4].formals;
		    yyval.parms.set = yyvsp[-3].formals;
		    yyval.parms.out = yyvsp[-2].formals;
		    yyval.parms.state = yyvsp[-1].formals;
		    yyval.parms.polarisation = yyvsp[0].polform;
		  ;}
    break;

  case 8:
#line 181 "instrument.y"
    {
		    yyval.formals = list_create();
		  ;}
    break;

  case 9:
#line 185 "instrument.y"
    {
		    yyval.formals = yyvsp[0].comp_iformals;
		  ;}
    break;

  case 10:
#line 191 "instrument.y"
    {
		    yyval.formals = list_create();
		  ;}
    break;

  case 11:
#line 195 "instrument.y"
    {
		    yyval.formals = yyvsp[0].comp_iformals;
		  ;}
    break;

  case 12:
#line 201 "instrument.y"
    {
		    yyval.formals = list_create();
		  ;}
    break;

  case 13:
#line 205 "instrument.y"
    {
		    yyval.formals = yyvsp[0].formals;
		  ;}
    break;

  case 14:
#line 211 "instrument.y"
    {
		    yyval.formals = yyvsp[0].formals;
		  ;}
    break;

  case 15:
#line 217 "instrument.y"
    {
		    yyval.polform = NULL;
		  ;}
    break;

  case 16:
#line 221 "instrument.y"
    {
		    char **polform;
		    nalloc(polform, 3);
		    polform[0] = yyvsp[-5].string;
		    polform[1] = yyvsp[-3].string;
		    polform[2] = yyvsp[-1].string;
		    yyval.polform = polform;
		  ;}
    break;

  case 17:
#line 232 "instrument.y"
    {
		    yyval.comp_iformals = yyvsp[-1].comp_iformals;
		  ;}
    break;

  case 18:
#line 238 "instrument.y"
    {
		    yyval.comp_iformals = list_create();
		  ;}
    break;

  case 19:
#line 242 "instrument.y"
    {
		    yyval.comp_iformals = yyvsp[0].comp_iformals;
		  ;}
    break;

  case 20:
#line 248 "instrument.y"
    {
		    yyval.comp_iformals = list_create();
		    list_add(yyval.comp_iformals, yyvsp[0].cformal);
		  ;}
    break;

  case 21:
#line 253 "instrument.y"
    {
		    list_add(yyvsp[-2].comp_iformals, yyvsp[0].cformal);
		    yyval.comp_iformals = yyvsp[-2].comp_iformals;
		  ;}
    break;

  case 22:
#line 260 "instrument.y"
    {
		    struct comp_iformal *formal;
		    palloc(formal);
		    if(!strcmp(yyvsp[-1].string, "double")) {
		      formal->type = instr_type_double;
		    } else if(!strcmp(yyvsp[-1].string, "int")) {
		      formal->type = instr_type_int;
		    } else if(!strcmp(yyvsp[-1].string, "string")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s for component "
				  "parameter %s at line %s:%d.\n", yyvsp[-1].string, yyvsp[0].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
		    formal->id = yyvsp[0].string;
		    yyval.cformal = formal;
		  ;}
    break;

  case 23:
#line 278 "instrument.y"
    {
		    struct comp_iformal *formal;
		    palloc(formal);
		    if(!strcmp(yyvsp[-2].string, "char")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s* for component "
				  "parameter %s at line $s:%d.\n", yyvsp[-2].string, yyvsp[0].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
		    formal->id = yyvsp[0].string;
		    yyval.cformal = formal;
		  ;}
    break;

  case 24:
#line 292 "instrument.y"
    {
		    struct comp_iformal *formal;
		    palloc(formal);
		    formal->id = str_dup(yyvsp[0].string);
		    formal->isoptional = 0; /* No default value */
        formal->type = instr_type_double;
		    yyval.cformal = formal;
		  ;}
    break;

  case 25:
#line 301 "instrument.y"
    {
		    struct comp_iformal *formal;
		    palloc(formal);
		    formal->id = yyvsp[-2].string;
		    formal->isoptional = 1; /* Default value available */
		    formal->default_value = yyvsp[0].exp;
        formal->type = instr_type_double;
		    yyval.cformal = formal;
		  ;}
    break;

  case 26:
#line 311 "instrument.y"
    {
		    struct comp_iformal *formal;
		    palloc(formal);
        if(!strcmp(yyvsp[-3].string, "double")) {
		      formal->type = instr_type_double;
		    } else if(!strcmp(yyvsp[-3].string, "int")) {
		      formal->type = instr_type_int;
		    } else if(!strcmp(yyvsp[-3].string, "string")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s for component "
				  "parameter %s at line %s:%d.\n", yyvsp[-3].string, yyvsp[-2].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
        formal->id = yyvsp[-2].string;
		    formal->isoptional = 1; /* Default value available */
		    formal->default_value = yyvsp[0].exp;
		    yyval.cformal = formal;
		  ;}
    break;

  case 27:
#line 331 "instrument.y"
    {
		    struct comp_iformal *formal;
		    palloc(formal);
		    formal->id = yyvsp[-2].string;
		    formal->isoptional = 1; /* Default value available */
		    formal->default_value = yyvsp[0].exp;
        if(!strcmp(yyvsp[-4].string, "char")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s* for component "
				  "parameter %s at line %s:%d.\n", yyvsp[-4].string, yyvsp[-2].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
		    yyval.cformal = formal;
      ;}
    break;

  case 28:
#line 349 "instrument.y"
    { instrument_definition->formals = yyvsp[0].iformals; instrument_definition->name = yyvsp[-1].string; ;}
    break;

  case 29:
#line 351 "instrument.y"
    {
		    instrument_definition->decls = yyvsp[-6].ccode;
		    instrument_definition->inits = yyvsp[-5].ccode;
		    instrument_definition->nxdinfo = yyvsp[-4].nxdinfo;
        instrument_definition->saves  = yyvsp[-2].ccode;
		    instrument_definition->finals = yyvsp[-1].ccode;
		    instrument_definition->compmap = comp_instances;
        instrument_definition->groupmap = group_instances;  /* ADD: E. Farhi Sep 25th, 2001 */
		    instrument_definition->complist = comp_instances_list;
        instrument_definition->grouplist = group_instances_list;  /* ADD: E. Farhi Sep 25th, 2001 */

		    /* Check instrument parameters for uniqueness */
		    check_instrument_formals(instrument_definition->formals,
					     instrument_definition->name);
        if (verbose) fprintf(stderr, "Creating instrument %s\n", instrument_definition->name);
		  ;}
    break;

  case 30:
#line 372 "instrument.y"
    {
		    yyval.iformals = yyvsp[-1].iformals;
		  ;}
    break;

  case 31:
#line 378 "instrument.y"
    {
		    yyval.iformals = list_create();
		  ;}
    break;

  case 32:
#line 382 "instrument.y"
    {
		    yyval.iformals = yyvsp[0].iformals;
		  ;}
    break;

  case 33:
#line 388 "instrument.y"
    {
		    yyval.iformals = list_create();
		    list_add(yyval.iformals, yyvsp[0].iformal);
		  ;}
    break;

  case 34:
#line 393 "instrument.y"
    {
		    list_add(yyvsp[-2].iformals, yyvsp[0].iformal);
		    yyval.iformals = yyvsp[-2].iformals;
		  ;}
    break;

  case 35:
#line 400 "instrument.y"
    {
		    struct instr_formal *formal;
		    palloc(formal);
		    if(!strcmp(yyvsp[-1].string, "double")) {
		      formal->type = instr_type_double;
		    } else if(!strcmp(yyvsp[-1].string, "int")) {
		      formal->type = instr_type_int;
		    } else if(!strcmp(yyvsp[-1].string, "string")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s for instrument "
				  "parameter %s at line %s:%d.\n", yyvsp[-1].string, yyvsp[0].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
		    formal->id = yyvsp[0].string;
		    yyval.iformal = formal;
		  ;}
    break;

  case 36:
#line 418 "instrument.y"
    {
		    struct instr_formal *formal;
		    palloc(formal);
		    if(!strcmp(yyvsp[-2].string, "char")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type $s* for instrument "
				  "parameter %s at line %s:%d.\n", yyvsp[-2].string, yyvsp[0].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
		    formal->id = yyvsp[0].string;
		    yyval.iformal = formal;
		  ;}
    break;

  case 37:
#line 432 "instrument.y"
    {
		    struct instr_formal *formal;
		    palloc(formal);
		    formal->type = instr_type_double;
		    formal->id = yyvsp[0].string;
        formal->isoptional = 0; /* No default value */
		    yyval.iformal = formal;
		  ;}
    break;

  case 38:
#line 441 "instrument.y"
    {
		    struct instr_formal *formal;
		    palloc(formal);
		    formal->id = yyvsp[-2].string;
		    formal->isoptional = 1; /* Default value available */
		    formal->default_value = yyvsp[0].exp;
        formal->type = instr_type_double;
		    yyval.iformal = formal;
		  ;}
    break;

  case 39:
#line 451 "instrument.y"
    {
		    struct instr_formal *formal;
		    palloc(formal);
        if(!strcmp(yyvsp[-3].string, "double")) {
		      formal->type = instr_type_double;
		    } else if(!strcmp(yyvsp[-3].string, "int")) {
		      formal->type = instr_type_int;
		    } else if(!strcmp(yyvsp[-3].string, "string")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s for instrument "
				  "parameter %s at line %s:%d.\n", yyvsp[-3].string, yyvsp[-2].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
        formal->id = yyvsp[-2].string;
		    formal->isoptional = 1; /* Default value available */
		    formal->default_value = yyvsp[0].exp;
		    yyval.iformal = formal;
		  ;}
    break;

  case 40:
#line 471 "instrument.y"
    {
		    struct instr_formal *formal;
		    palloc(formal);
		    formal->id = yyvsp[-2].string;
		    formal->isoptional = 1; /* Default value available */
		    formal->default_value = yyvsp[0].exp;
        if(!strcmp(yyvsp[-4].string, "char")) {
		      formal->type = instr_type_string;
		    } else {
		      print_error("Illegal type %s* for instrument "
				  "parameter %s at line %s:%d.\n", yyvsp[-4].string, yyvsp[-2].string, instr_current_filename, instr_current_line);
		      formal->type = instr_type_double;
		    }
		    yyval.iformal = formal;
      ;}
    break;

  case 41:
#line 488 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 42:
#line 492 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 43:
#line 498 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 44:
#line 502 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 45:
#line 509 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 46:
#line 513 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 47:
#line 520 "instrument.y"
    {
		    struct NXDinfo *nxdinfo;
		    palloc(nxdinfo);
		    nxdinfo->nxdfile = NULL;
		    nxdinfo->any = 0;
		    yyval.nxdinfo = nxdinfo;
		  ;}
    break;

  case 48:
#line 528 "instrument.y"
    { /* ADD: E.Farhi Aug 6th 2002: use default NeXus dictionary file */
		    struct NXDinfo *nxdinfo = yyvsp[-3].nxdinfo;
		    if(nxdinfo->nxdfile)
		    {
		      print_error("Multiple NeXus DICTFILE declarations found (%s).\n"
				  "At most one NeXus DICTFILE declarations may "
				  "be used in an instrument", nxdinfo->nxdfile);
		    }
		    else 
        {
          nxdinfo->nxdfile     = yyvsp[-1].string;
          nxdinfo->hdfversion = atof(yyvsp[0].number);
        }
		    nxdinfo->any = 1; /* Now need NeXus support in runtime */
		    yyval.nxdinfo = nxdinfo;
		  ;}
    break;

  case 49:
#line 546 "instrument.y"
    {
		    yyval.string = str_cat(instrument_definition->name, ".dic", NULL);
		  ;}
    break;

  case 50:
#line 550 "instrument.y"
    {
        yyval.string = yyvsp[0].string;
      ;}
    break;

  case 51:
#line 555 "instrument.y"
    {
		    yyval.number = "4";
		  ;}
    break;

  case 52:
#line 559 "instrument.y"
    {
        yyval.number = yyvsp[0].number;
      ;}
    break;

  case 53:
#line 565 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 54:
#line 571 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 55:
#line 575 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 56:
#line 581 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 57:
#line 585 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 58:
#line 591 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 59:
#line 595 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 61:
#line 603 "instrument.y"
    {
		    comp_instances      = symtab_create();
		    comp_instances_list = list_create();
        group_instances     = symtab_create();
        group_instances_list= list_create();
		  ;}
    break;

  case 62:
#line 610 "instrument.y"
    {
		    /* Check that the component instance name has not
                       been used before. */
		    if(symtab_lookup(comp_instances, yyvsp[0].instance->name))
		    {
		      print_error("Multiple use of component instance name "
				  "'%s' at line %s:%d.\n", yyvsp[0].instance->name, instr_current_filename, instr_current_line);
		      /* Since this is an error condition, we do not
		         worry about freeing the memory allocated for
			 the component instance. */
		    }
		    else
		    {
		      symtab_add(comp_instances, yyvsp[0].instance->name, yyvsp[0].instance);
		      list_add(comp_instances_list, yyvsp[0].instance);
		      if(yyvsp[0].instance->def)
		      {
            /* Check if the component handles polarisation. */
            if(yyvsp[0].instance->def->polarisation_par)
            {
	            instrument_definition->polarised = 1;
            }
		      }
		    }
		  ;}
    break;

  case 63:
#line 638 "instrument.y"
    {
		    struct comp_def *def;
		    struct comp_inst *comp;
        
        def = read_component(yyvsp[-5].string);
        if (def != NULL) def->comp_inst_number--;
		    palloc(comp); /* Allocate new instance. */
		    comp->name = yyvsp[-7].string;
		    comp->def = def;
		    palloc(comp->pos);
        comp->group = yyvsp[-1].groupinst;           /* ADD: E. Farhi Sep 24th, 2001 component is part of an exclusive group */
        comp->extend = yyvsp[0].ccode;  /* ADD: E. Farhi Sep 20th, 2001 EXTEND block*/
        comp->index = 0;       /* ADD: E. Farhi Sep 20th, 2001 index of comp instance */
		    comp->pos->place = yyvsp[-3].place.place;
		    comp->pos->place_rel = yyvsp[-3].place.place_rel;
		    comp->pos->orientation = yyvsp[-2].ori.orientation;
		    comp->pos->orientation_rel =
		      yyvsp[-2].ori.isdefault ? yyvsp[-3].place.place_rel : yyvsp[-2].ori.orientation_rel;
		    if(def != NULL)
		    {
		      /* Check actual parameters against definition and
                         setting parameters. */
		      comp_formals_actuals(comp, yyvsp[-4].actuals);
		    }
		    str_free(yyvsp[-5].string);
		    debugn((DEBUG_HIGH, "Component: %s.\n", yyvsp[-7].string));
        previous_comp = comp; /* this comp will be 'previous' for the next */
		    yyval.instance = comp;
		  ;}
    break;

  case 64:
#line 670 "instrument.y"
    {
		    yyval.formals = yyvsp[-1].formals;
		  ;}
    break;

  case 65:
#line 677 "instrument.y"
    {
		    yyval.formals = list_create();
		  ;}
    break;

  case 66:
#line 681 "instrument.y"
    {
		    yyval.formals = yyvsp[0].formals;
		  ;}
    break;

  case 67:
#line 687 "instrument.y"
    {
		    yyval.formals = list_create();
		    list_add(yyval.formals, yyvsp[0].string);
		  ;}
    break;

  case 68:
#line 692 "instrument.y"
    {
		    list_add(yyvsp[-2].formals, yyvsp[0].string);
		    yyval.formals = yyvsp[-2].formals;
		  ;}
    break;

  case 69:
#line 699 "instrument.y"
    {
		    yyval.actuals = yyvsp[-1].actuals;
		  ;}
    break;

  case 70:
#line 705 "instrument.y"
    {
		    yyval.actuals = symtab_create();
		  ;}
    break;

  case 71:
#line 709 "instrument.y"
    {
		    yyval.actuals = yyvsp[0].actuals;
		  ;}
    break;

  case 72:
#line 715 "instrument.y"
    {
		    yyval.actuals = symtab_create();
		    symtab_add(yyval.actuals, yyvsp[-2].string, yyvsp[0].exp);
		    str_free(yyvsp[-2].string);
		  ;}
    break;

  case 73:
#line 721 "instrument.y"
    {
		    symtab_add(yyvsp[-4].actuals, yyvsp[-2].string, yyvsp[0].exp);
		    str_free(yyvsp[-2].string);
		    yyval.actuals = yyvsp[-4].actuals;
		  ;}
    break;

  case 74:
#line 729 "instrument.y"
    {
		    yyval.place.place = yyvsp[-1].coords;
		    yyval.place.place_rel = yyvsp[0].instance;
		  ;}
    break;

  case 75:
#line 736 "instrument.y"
    {
		    yyval.ori.orientation = coords_exp_origo(); /* Default to (0,0,0). */
		    yyval.ori.isdefault = 1; /* No ROTATED modifier was present */
		  ;}
    break;

  case 76:
#line 741 "instrument.y"
    {
		    yyval.ori.orientation = yyvsp[-1].coords;
		    yyval.ori.orientation_rel = yyvsp[0].instance;
		    yyval.ori.isdefault = 0;
		  ;}
    break;

  case 77:
#line 750 "instrument.y"
    {
		    yyval.instance = NULL;
		  ;}
    break;

  case 78:
#line 754 "instrument.y"
    {
        if (previous_comp) {
          yyval.instance = previous_comp; 
        } else {
          print_warn(NULL, "Found invalid PREVIOUS reference at line %s:%d. Using ABSOLUTE.\n", instr_current_filename, instr_current_line);
          yyval.instance = NULL;
        }
      ;}
    break;

  case 79:
#line 763 "instrument.y"
    {
        /* get the $4 previous item in comp_instances */
        struct Symtab_entry *entry;
        int index;
        index = atoi(yyvsp[-1].number);
        entry = symtab_previous(comp_instances, index);
        if (!index) { /* invalid index reference */
          print_warn(NULL, "Found invalid PREVIOUS(%i) reference at line %s:%d. Using ABSOLUTE.\n", index, instr_current_filename, instr_current_line);
          yyval.instance = NULL;
        } else {  
          yyval.instance = entry->val;
        }
      ;}
    break;

  case 80:
#line 777 "instrument.y"
    {
		    yyval.instance = yyvsp[0].instance;
		  ;}
    break;

  case 81:
#line 784 "instrument.y"
    {
        yyval.groupinst = NULL;
		  ;}
    break;

  case 82:
#line 788 "instrument.y"
    {
        yyval.groupinst = yyvsp[0].groupinst;
		  ;}
    break;

  case 83:
#line 794 "instrument.y"
    {
        struct group_inst *group;
        struct Symtab_entry *ent;
        
        ent = symtab_lookup(group_instances, yyvsp[0].string);
        if(ent == NULL)
        {
          palloc(group);    /* create new group instance */
          group->name = yyvsp[0].string;  
          group->index= 0;
          symtab_add(group_instances, yyvsp[0].string, group);
		      list_add(group_instances_list, group);
        }
        else
          group = ent->val;  
        yyval.groupinst = group;
      ;}
    break;

  case 84:
#line 814 "instrument.y"
    {
		    struct comp_inst *comp;
		    struct Symtab_entry *ent;

		    ent = symtab_lookup(comp_instances, yyvsp[0].string);
		    comp = NULL;
		    if(ent == NULL)
		      print_error("Reference to undefined component %s at line %s:%d.\n",
				  yyvsp[0].string, instr_current_filename, instr_current_line);
		    else
		      comp = ent->val;
		    str_free(yyvsp[0].string);
		    yyval.instance = comp;
		  ;}
    break;

  case 85:
#line 831 "instrument.y"
    {
		    yyval.coords.x = yyvsp[-5].exp;
		    yyval.coords.y = yyvsp[-3].exp;
		    yyval.coords.z = yyvsp[-1].exp;
		  ;}
    break;

  case 86:
#line 840 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 87:
#line 844 "instrument.y"
    {
		    yyval.ccode = yyvsp[0].ccode;
		  ;}
    break;

  case 88:
#line 851 "instrument.y"
    { yyval.linenum = instr_current_line; ;}
    break;

  case 89:
#line 852 "instrument.y"
    {
		    CExp e = yyvsp[0].exp;
		    exp_setlineno(e, yyvsp[-1].linenum );
		    yyval.exp = e;
		  ;}
    break;

  case 90:
#line 857 "instrument.y"
    { yyval.linenum = instr_current_line; ;}
    break;

  case 91:
#line 858 "instrument.y"
    {
		    CExp e;
		    /* Note: "EXTERN" is now obsolete and redundant. */
		    e = exp_extern_id(yyvsp[0].string);
		    exp_setlineno(e, yyvsp[-1].linenum );
		    str_free(yyvsp[0].string);
		    yyval.exp = e;
		  ;}
    break;

  case 92:
#line 869 "instrument.y"
    {
		    yyval.exp = yyvsp[0].exp;
		  ;}
    break;

  case 93:
#line 873 "instrument.y"
    {
		    yyval.exp = exp_compound(2, yyvsp[-1].exp, yyvsp[0].exp);
		    exp_free(yyvsp[0].exp);
		    exp_free(yyvsp[-1].exp);
		  ;}
    break;

  case 94:
#line 883 "instrument.y"
    {
		    List_handle liter;
		    struct instr_formal *formal;
		    /* Check if this is an instrument parameter or not. */
		    /* ToDo: This will be inefficient if the number of
                       instrument parameters is really huge. */
		    liter = list_iterate(instrument_definition->formals);
		    while(formal = list_next(liter))
		    {
		      if(!strcmp(yyvsp[0].string, formal->id))
		      {
			      /* It was an instrument parameter */
			      yyval.exp = exp_id(yyvsp[0].string);
			      goto found;
		      }
		    }
		    /* It was an external id. */
		    yyval.exp = exp_extern_id(yyvsp[0].string);
		  found:
		    str_free(yyvsp[0].string);
		  ;}
    break;

  case 95:
#line 905 "instrument.y"
    {
		    yyval.exp = exp_number(yyvsp[0].number);
		    str_free(yyvsp[0].number);
		  ;}
    break;

  case 96:
#line 910 "instrument.y"
    {
		    yyval.exp = exp_string(yyvsp[0].string);
		    str_free(yyvsp[0].string);
		  ;}
    break;

  case 97:
#line 915 "instrument.y"
    {
		    yyval.exp = exp_ctoken(yyvsp[0].string);
		    str_free(yyvsp[0].string);
		  ;}
    break;

  case 98:
#line 920 "instrument.y"
    {
		    yyval.exp = exp_ctoken("=");
		  ;}
    break;

  case 99:
#line 924 "instrument.y"
    {
		    yyval.exp = exp_ctoken("*");
		  ;}
    break;

  case 100:
#line 928 "instrument.y"
    {
		    CExp p1 = exp_ctoken("(");
		    CExp p2 = exp_ctoken(")");
		    yyval.exp = exp_compound(3, p1, yyvsp[-1].exp, p2);
		    exp_free(p2);
		    exp_free(p1);
		    exp_free(yyvsp[-1].exp);
		  ;}
    break;

  case 101:
#line 937 "instrument.y"
    {
		    CExp p1 = exp_ctoken("(");
		    CExp p2 = exp_ctoken(")");
		    yyval.exp = exp_compound(2, p1, p2);
		    exp_free(p2);
		    exp_free(p1);
		  ;}
    break;

  case 102:
#line 945 "instrument.y"
    {
		    CExp p1 = exp_ctoken("[");
		    CExp p2 = exp_ctoken("]");
		    yyval.exp = exp_compound(3, p1, yyvsp[-1].exp, p2);
		    exp_free(p2);
		    exp_free(p1);
		    exp_free(yyvsp[-1].exp);
		  ;}
    break;

  case 103:
#line 954 "instrument.y"
    {
		    CExp p1 = exp_ctoken("[");
		    CExp p2 = exp_ctoken("]");
		    yyval.exp = exp_compound(2, p1, p2);
		    exp_free(p2);
		    exp_free(p1);
		  ;}
    break;

  case 104:
#line 962 "instrument.y"
    {
		    CExp p1 = exp_ctoken("{");
		    CExp p2 = exp_ctoken("}");
		    yyval.exp = exp_compound(3, p1, yyvsp[-1].exp, p2);
		    exp_free(p2);
		    exp_free(p1);
		    exp_free(yyvsp[-1].exp);
		  ;}
    break;

  case 105:
#line 971 "instrument.y"
    {
		    CExp p1 = exp_ctoken("{");
		    CExp p2 = exp_ctoken("}");
		    yyval.exp = exp_compound(2, p1, p2);
		    exp_free(p2);
		    exp_free(p1);
		  ;}
    break;

  case 106:
#line 982 "instrument.y"
    {
		    yyval.exp = yyvsp[0].exp;
		  ;}
    break;

  case 107:
#line 986 "instrument.y"
    {
		    yyval.exp = exp_compound(2, yyvsp[-1].exp, yyvsp[0].exp);
		    exp_free(yyvsp[0].exp);
		    exp_free(yyvsp[-1].exp);
		  ;}
    break;

  case 108:
#line 994 "instrument.y"
    {
		    yyval.exp = yyvsp[0].exp;
		  ;}
    break;

  case 109:
#line 998 "instrument.y"
    {
		    yyval.exp = exp_ctoken(",");
		  ;}
    break;

  case 110:
#line 1004 "instrument.y"
    {
		    yyvsp[-1].ccode->filename = instr_current_filename;
		    yyvsp[-1].ccode->quoted_filename = str_quote(instr_current_filename);
		    yyvsp[-1].ccode->linenum = yyvsp[-2].linenum;
		    yyval.ccode = yyvsp[-1].ccode;
		  ;}
    break;

  case 111:
#line 1013 "instrument.y"
    {
		    yyval.ccode = codeblock_new();
		  ;}
    break;

  case 112:
#line 1018 "instrument.y"
    {
        list_add(yyvsp[-1].ccode->lines, yyvsp[0].string);
		    yyval.ccode = yyvsp[-1].ccode;
		  ;}
    break;


    }

/* Line 999 of yacc.c.  */
#line 2377 "instrument.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  YYSIZE_T yysize = 0;
	  int yytype = YYTRANSLATE (yychar);
	  char *yymsg;
	  int yyx, yycount;

	  yycount = 0;
	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  for (yyx = yyn < 0 ? -yyn : 0;
	       yyx < (int) (sizeof (yytname) / sizeof (char *)); yyx++)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      yysize += yystrlen (yytname[yyx]) + 15, yycount++;
	  yysize += yystrlen ("syntax error, unexpected ") + 1;
	  yysize += yystrlen (yytname[yytype]);
	  yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg != 0)
	    {
	      char *yyp = yystpcpy (yymsg, "syntax error, unexpected ");
	      yyp = yystpcpy (yyp, yytname[yytype]);

	      if (yycount < 5)
		{
		  yycount = 0;
		  for (yyx = yyn < 0 ? -yyn : 0;
		       yyx < (int) (sizeof (yytname) / sizeof (char *));
		       yyx++)
		    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
		      {
			const char *yyq = ! yycount ? ", expecting " : " or ";
			yyp = yystpcpy (yyp, yyq);
			yyp = yystpcpy (yyp, yytname[yyx]);
			yycount++;
		      }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    yyerror ("syntax error; also virtual memory exhausted");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror ("syntax error");
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      /* Return failure if at end of input.  */
      if (yychar == YYEOF)
        {
	  /* Pop the error token.  */
          YYPOPSTACK;
	  /* Pop the rest of the stack.  */
	  while (yyss < yyssp)
	    {
	      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
	      yydestruct (yystos[*yyssp], yyvsp);
	      YYPOPSTACK;
	    }
	  YYABORT;
        }

      YYDSYMPRINTF ("Error: discarding", yytoken, &yylval, &yylloc);
      yydestruct (yytoken, &yylval);
      yychar = YYEMPTY;

    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*----------------------------------------------------.
| yyerrlab1 -- error raised explicitly by an action.  |
`----------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      YYDSYMPRINTF ("Error: popping", yystos[*yyssp], yyvsp, yylsp);
      yydestruct (yystos[yystate], yyvsp);
      yyvsp--;
      yystate = *--yyssp;

      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  YYDPRINTF ((stderr, "Shifting error token, "));

  *++yyvsp = yylval;


  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*----------------------------------------------.
| yyoverflowlab -- parser overflow comes here.  |
`----------------------------------------------*/
yyoverflowlab:
  yyerror ("parser stack overflow");
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 1024 "instrument.y"


static Pool parser_pool = NULL;	/* Pool of parser allocations. */

static int mc_yyparse(void)
{
  int ret;
  Pool oldpool;

  oldpool = parser_pool;
  parser_pool = pool_create();
  ret = yyparse();
  pool_free(parser_pool);
  parser_pool = oldpool;
  return ret;
}
    
/* Name of the file currently being parsed. */
char *instr_current_filename = NULL;
/* Number of the line currently being parsed. */
int instr_current_line = 0;

/* Result from parsing instrument definition. */
struct instr_def *instrument_definition;

/* Map from names to component instances. */
Symtab comp_instances;

/* Will store component instance for PREVIOUS reference */
struct comp_inst *previous_comp=NULL;

/* ADD: E. Farhi Sep 24th, 2001 Map from names to component group instances. */
Symtab group_instances;

/* Map from names to embedded libraries */
Symtab lib_instances;

/* List of components, in the order they where declared in the instrument
   definition. */
List comp_instances_list;

/* List of component groups, in the order they where declared in the instrument
   definition. */
List group_instances_list;

/* Filename for outputting generated simulation program ('-' means stdin). */
static char *output_filename;

/* Verbose parsing/code generation */
char verbose;

/* Map of already-read components. */
Symtab read_components = NULL;

/* Print a summary of the command usage and exit with error. */
static void
print_usage(void)
{
  fprintf(stderr, "Usage:\n"
	  "  mcstas [-o file] [-I dir1 ...] [-t] [-p] [-v] "
	  "[--no-main] [--no-runtime] [--verbose] file\n");
  fprintf(stderr, "      -o FILE --output-file=FILE Place C output in file FILE.\n");
  fprintf(stderr, "      -I DIR  --search-dir=DIR   Append DIR to the component search list. \n");
  fprintf(stderr, "      -t      --trace            Enable 'trace' mode for instrument display.\n");
  fprintf(stderr, "      -v      --version          Prints McStas version.\n");
  fprintf(stderr, "      --no-main                  Do not create main(), for external embedding.\n");
  fprintf(stderr, "      --no-runtime               Do not embed run-time libraries.\n");
  fprintf(stderr, "      --verbose                  Display compilation process steps.\n");
  fprintf(stderr, "  The file will be processed and translated into a C code program.\n");
  fprintf(stderr, "  The default component search list is usually defined by the 'MCSTAS'\n");
  fprintf(stderr, "  environment variable. Use 'mcrun' to both run mcstas and the C compiler.\n");
  fprintf(stderr, "  If run-time libraries are not embedded, you will have to pre-compile\n");
  fprintf(stderr, "  them (.c -> .o) before assembling the program.\n");
  fprintf(stderr, "SEE ALSO: mcrun, mcplot, mcdisplay, mcresplot, mcstas2vitess, mcgui\n");
  fprintf(stderr, "DOC:      Please visit http://neutron.risoe.dk/mcstas/\n");
  exit(1);
}

/* Print McStas version and copyright. */
static void
print_version(void)
{ /* MOD: E. Farhi Sep 20th, 2001 version number */
  printf("McStas version " MCSTAS_VERSION "\n"
	  "Copyright (C) Risoe National Laboratory, 1997-2003\n"
    "Additions (C) Institut Laue Langevin, 2003\n"
	  "All rights reserved\n");
  exit(0);
}

/* Construct default filename for simulation output from instrument file
   name. Strip any leading directory path and trailing .instr, and add .c to
   the end. */
static char *
make_output_filename(char *name)
{
  char *p;
  int l;

  /* Find basename */
  p = strrchr(name, '/');
  if(p == NULL)
    p = name;			/* No initial path. */
  else
    p++;			/* Point past last '/' character. */

  /* Check for trailing .instr suffix. */
  l = strlen(p);
  if(l > 6 && !strcmp(&p[l - 6], ".instr"))
  {
    char *tmp = str_dup(p);
    tmp[l - 6] = '\0';
    p = str_cat(tmp, ".c", NULL);
    str_free(tmp);
  }
  else
    p = str_cat(p, ".c", NULL);
  return p;
}


static void
set_output_filename(char *name)
{
  output_filename = str_dup(name);
}

/* Parse command line options. */
static void
parse_command_line(int argc, char *argv[])
{
  int i;

  output_filename = NULL;
  verbose = 0;
  instr_current_filename = NULL;
  instrument_definition->use_default_main = 1;
  instrument_definition->include_runtime = 1;
  instrument_definition->enable_trace = 0;
  instrument_definition->portable = 0;
  instrument_definition->polarised = 0;
  for(i = 1; i < argc; i++)
  {
    if(!strcmp("-o", argv[i]) && (i + 1) < argc)
      set_output_filename(argv[++i]);
    else if(!strncmp("-o", argv[i], 2))
      set_output_filename(&argv[i][2]);
    else if(!strcmp("--output-file", argv[i]) && (i + 1) < argc)
      set_output_filename(argv[++i]);
    else if(!strncmp("--output-file=", argv[i], 14))
      set_output_filename(&argv[i][14]);
    else if(!strcmp("-I", argv[i]) && (i + 1) < argc)
      add_search_dir(argv[++i]);
    else if(!strncmp("-I", argv[i], 2))
      add_search_dir(&argv[i][2]);
    else if(!strcmp("--search-dir", argv[i]) && (i + 1) < argc)
      add_search_dir(argv[++i]);
    else if(!strncmp("--search-dir=", argv[i], 13))
      add_search_dir(&argv[i][13]);
    else if(!strcmp("-t", argv[i]))
      instrument_definition->enable_trace = 1;
    else if(!strcmp("--trace", argv[i]))
      instrument_definition->enable_trace = 1;
    else if(!strcmp("-p", argv[i]))
      instrument_definition->portable = 1;
    else if(!strcmp("--portable", argv[i]))
      instrument_definition->portable = 1;
    else if(!strcmp("-v", argv[i]))
      print_version();
    else if(!strcmp("--version", argv[i]))
      print_version();
    else if(!strcmp("--verbose", argv[i]))
      verbose = 1;
    else if(!strcmp("--no-main", argv[i]))
      instrument_definition->use_default_main = 0;
    else if(!strcmp("--no-runtime", argv[i]))
      instrument_definition->include_runtime = 0;
    else if(argv[i][0] != '-')
    {
      if(instr_current_filename != NULL)
        print_usage();		/* Multiple instruments given. */
      instr_current_filename = str_dup(argv[i]);
    }
    else
      print_usage();
  }

  /* Instrument filename must be given. */
  if(instr_current_filename == NULL)
    print_usage();
  /* If no '-o' option was given for INSTR.instr, default to INSTR.c  */
  if(output_filename == NULL)
    output_filename = make_output_filename(instr_current_filename);
}


int
main(int argc, char *argv[])
{
  FILE *file;
  int err;

#ifdef MAC
  argc = ccommand(&argv);
#endif

  yydebug = 0;			/* If 1, then bison gives verbose parser debug info. */

  palloc(instrument_definition); /* Allocate instrument def. structure. */
  parse_command_line(argc, argv);
  if(!strcmp(instr_current_filename, "-"))
  {
    instrument_definition->source = str_dup("<stdin>");
    file = fdopen(0, "r");	/* Lone '-' designates stdin. */
  }
  else
  {
    instrument_definition->source = str_dup(instr_current_filename);
    file = fopen(instr_current_filename, "r");
  }
  if(file == NULL)
    fatal_error("Instrument definition file `%s' not found\n",
		instr_current_filename);
  instrument_definition->quoted_source =
    str_quote(instrument_definition->source);
  instr_current_line = 1;
  lex_new_file(file);
  read_components = symtab_create(); /* Create table of components. */
  lib_instances   = symtab_create(); /* Create table of libraries. */
  err = mc_yyparse();
  fclose(file);
  if(err != 0 || error_encountered != 0)
  {
    print_error("Errors encountered during parse.\n");
    exit(1);
  }
  else
  {

    cogen(output_filename, instrument_definition);
    if (verbose) fprintf(stderr, "Generating code     %s\n", output_filename);
    exit(0);
  }
}


int
yyerror(char *s)
{
  print_error("%s at line %d.\n", s, instr_current_line);
  return 0;
}


/*******************************************************************************
* Check that all formal parameters of a component definition are unique.
*******************************************************************************/
void
check_comp_formals(List deflist, List setlist, char *compname)
{
  Symtab formals;
  struct comp_iformal *formal;
  struct Symtab_entry *entry;
  List_handle liter;

  /* We check the uniqueness by adding all the formals to a symbol table with
     a dummy pointer value. Any formal parameter that already appears in the
     symbol table is an error. */
  formals = symtab_create();
  liter = list_iterate(deflist);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(formals, formal->id);
    if(entry != NULL)
      print_error("Definition parameter name %s is used multiple times "
		  "in component %s\n", formal->id, compname);
    else
      symtab_add(formals, formal->id, NULL);
  }
  list_iterate_end(liter);
  liter = list_iterate(setlist);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(formals, formal->id);
    if(entry != NULL)
      print_error("Setting parameter name %s is used multiple times "
		  "in component %s\n", formal->id, compname);
    else
      symtab_add(formals, formal->id, NULL);
  }
  list_iterate_end(liter);
  symtab_free(formals, NULL);
}


/*******************************************************************************
* Check that all formal parameters of an instrument definition are unique.
*******************************************************************************/
void
check_instrument_formals(List formallist, char *instrname)
{
  Symtab formals;
  struct instr_formal *formal;
  struct Symtab_entry *entry;
  List_handle liter;

  /* We check the uniqueness by adding all the formals to a symbol table with
     a dummy pointer value. Any formal parameter that already appears in the
     symbol table is an error. */
  formals = symtab_create();
  liter = list_iterate(formallist);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(formals, formal->id);
    if(entry != NULL)
      print_error("Instrument parameter name %s is used multiple times "
		  "in instrument %s\n", formal->id, instrname);
    else
      symtab_add(formals, formal->id, NULL);
  }
  list_iterate_end(liter);
  symtab_free(formals, NULL);
}

/*******************************************************************************
* Check the actual parameters to a component against the formal parameters.
*******************************************************************************/
void
comp_formals_actuals(struct comp_inst *comp, Symtab actuals)
{
  List_handle liter;
  struct comp_iformal *formal;
  struct Symtab_entry *entry;
  Symtab defpar, setpar;
  Symtab_handle siter;
  
  /* We need to check
     1. That all actual parameters correspond to formal parameters.
     2. That all formal parameters are assigned actual parameters. */

  /* First check the formal parameters one by one. */
  defpar = symtab_create();
  setpar = symtab_create();
  liter = list_iterate(comp->def->def_par);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(actuals, formal->id);
    if(entry == NULL)
    {
      if(formal->isoptional)
      {
        /* Use default value for unassigned optional parameter */
        symtab_add(defpar, formal->id, formal->default_value);
      } else {
        print_error("Unassigned definition parameter %s for component %s.\n",
		          formal->id, comp->name);
        symtab_add(defpar, formal->id, exp_number("0.0"));
      }
    } else {
      symtab_add(defpar, formal->id, entry->val);
      /* Ensure that the actual DEFINITION parameters are all values
         (identifiers, constant numbers, and constant strings). This is
         necessary to avoid duplication of computations or side effects in the
         expressions for the actual parameters, since DEFINITION parameters
         are assigned using #define's. */
      if(!exp_isvalue(entry->val))
      {
        static int seenb4 = 0;	/* Only print long error the first time */
        print_error("Illegal expression for DEFINITION parameter %s of component %s.\n%s",
          formal->id, comp->name,
          ( seenb4++ ? "" :
	        "(Only variable names, constant numbers, and constant strings\n"
	        "are allowed for DEFINITION parameters.)\n") );
      }
    }
  }
  list_iterate_end(liter);
  liter = list_iterate(comp->def->set_par);
  while(formal = list_next(liter))
  {
    entry = symtab_lookup(actuals, formal->id);
    if(entry == NULL)
    {
      if(formal->isoptional)
      {
        /* Use default value for unassigned optional parameter */
        symtab_add(setpar, formal->id, formal->default_value);
      } else {
        print_error("Unassigned setting parameter %s for component %s.\n",
		          formal->id, comp->name);
        symtab_add(setpar, formal->id, exp_number("0.0"));
      }
    } else {
      symtab_add(setpar, formal->id, entry->val);
    }
  }
  list_iterate_end(liter);

  /* Now check the actual parameters one by one. */
  siter = symtab_iterate(actuals);
  while(entry = symtab_next(siter))
  {
    if(symtab_lookup(defpar, entry->name) == NULL &&
       symtab_lookup(setpar, entry->name) == NULL)
    {
      print_error("Unmatched actual parameter %s for component %s.\n",
		  entry->name, comp->name);
    }
  }
  comp->defpar = defpar;
  comp->setpar = setpar;
}


/*******************************************************************************
* This is the main entry point for reading a component. When a component
* definition is needed, this function is called with the name of the
* component. A map of previously read components is maintained. If a
* component definition (struct comp)def) is found, it is returned. Otherwise
* an attempt is made to read the component definition from a file with the
* same name as the component with added file extension ".com".
* If for some reasons the component cannot be read, NULL is returned; else a
* pointer to a struct comp_def is returned. Since components definitions can
* be used multiple times, the returned structure is shared and should not be
* modified.
*******************************************************************************/
struct comp_def *
read_component(char *name)
{
  struct Symtab_entry *entry;
  
  /* Look for an existing definition for the component. */
  entry = symtab_lookup(read_components, name);
  if(entry != NULL)
  {
    return entry->val;		/* Return it if found. */
  }
  else
  {
    FILE *file;
    int err;
    
    /* Attempt to read definition from file components/<name>.com. */
    file = open_component_search(name);
    if(file == NULL)
    {
      print_error(
        "Cannot find file containing definition of component `%s'.\n", name);
      return NULL;
    }
    push_autoload(file);
    /* Note: the str_dup copy of the file name is stored in codeblocks, and
       must not be freed. */
    instr_current_filename = component_pathname;
    instr_current_line = 1;
    err = mc_yyparse();		/* Read definition from file. */
    if(err != 0)
      fatal_error("Errors encountered during autoload of component %s.\n",
        name);
    fclose(file);
    /* Now check if the file contained the required component definition. */
    entry = symtab_lookup(read_components, name);
    if(entry != NULL)
    {
      return entry->val;
    }
    else
    {
      print_error("Definition of component %s not found.\n", name);
      return NULL;
    }
  }
}

